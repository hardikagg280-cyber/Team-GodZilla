/* Dashboard charts: privacy score ring, category risk radar, records by platform */
function dialSVG(){const R0=96,C=2*Math.PI*R0,n=CATS.length,gap=10,seg=C/n-gap;
  const arcs=CATS.map((c,i)=>{const f=S.findings.find(x=>x.cat===c.id);const col=f?LVC[f.level]:'var(--line)';
    return `<circle cx="120" cy="120" r="${R0}" fill="none" stroke="${col}" stroke-width="16" stroke-linecap="round" stroke-dasharray="${seg.toFixed(1)} ${(C-seg).toFixed(1)}" stroke-dashoffset="${(-i*C/n).toFixed(1)}" transform="rotate(-90 120 120)"><title>${esc(c.name)}: ${f?f.level:'not found'}</title></circle>`;}).join('');
  return `<svg class="dial" viewBox="0 0 240 240" role="img" aria-label="Privacy score ${S.score} out of 100">
    <circle cx="120" cy="120" r="70" fill="var(--surface-2)" stroke="var(--line)"/>
    <g class="arcs">${arcs}</g>
    <text x="120" y="122" text-anchor="middle" font-family="Bricolage Grotesque, sans-serif" font-size="54" font-weight="750" fill="var(--ink)">${S.score}</text>
    <text x="120" y="148" text-anchor="middle" font-size="12.5" fill="var(--muted)" font-family="Public Sans, sans-serif">out of 100</text></svg>`;}
function catCount(id){switch(id){case'location':return S.locations.length+S.places.length;case'search':return S.activities.filter(a=>a.type==='search').length;
  case'activity':return timedEvents().length;case'contacts':return uniqContacts(S.contacts).length;case'interests':return uniq(S.interests.map(i=>i.label.toLowerCase())).length+S.activities.filter(a=>a.type==='listen').length;case'identifiers':return S.identifiers.length;}return 0;}
function catValue(f){if(!f)return 0;const lw={High:1,Medium:0.66,Low:0.33}[f.level];const vol=Math.min(1,Math.log10((f.count||0)+1)/4);return Math.max(0.12,lw*0.7+vol*0.3);}
function radarSVG(){const W=600,H=360,cx=300,cy=180,R0=112,n=CATS.length;
  const pt=(i,r)=>{const a=-Math.PI/2+i*2*Math.PI/n;return[cx+Math.cos(a)*r,cy+Math.sin(a)*r];};
  let s=`<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-width:640px;display:block;margin:0 auto" role="img" aria-label="Relative risk by data category">`;
  for(let k=1;k<=4;k++){s+=`<polygon points="${CATS.map((c,i)=>pt(i,R0*k/4).map(v=>v.toFixed(1)).join(',')).join(' ')}" fill="none" stroke="var(--line)" stroke-width="1"/>`;}
  CATS.forEach((c,i)=>{const[x,y]=pt(i,R0);s+=`<line x1="${cx}" y1="${cy}" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" stroke="var(--line)"/>`;});
  const vals=CATS.map(c=>{const f=S.findings.find(x=>x.cat===c.id);return{c,f,v:catValue(f)};});
  s+=`<polygon class="radar-shape" points="${vals.map((o,i)=>pt(i,R0*o.v).map(v=>v.toFixed(1)).join(',')).join(' ')}" fill="var(--accent)" fill-opacity=".2" stroke="var(--accent)" stroke-width="2" stroke-linejoin="round"/>`;
  vals.forEach((o,i)=>{const[x,y]=pt(i,R0*o.v);s+=`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5" fill="${o.f?LVC[o.f.level]:'var(--line)'}" stroke="var(--surface)" stroke-width="2"><title>${esc(o.c.name)}: ${o.f?o.f.level+' risk':'not found'}</title></circle>`;
    const[lx,ly]=pt(i,R0+22);const anchor=Math.abs(lx-cx)<8?'middle':lx>cx?'start':'end';const dy=ly<cy-20?-8:ly>cy+20?14:4;
    s+=`<text x="${lx.toFixed(1)}" y="${(ly+dy).toFixed(1)}" text-anchor="${anchor}" font-size="15" fill="var(--ink)" font-weight="600">${esc(o.c.name)}</text><text x="${lx.toFixed(1)}" y="${(ly+dy+17).toFixed(1)}" text-anchor="${anchor}" font-size="13.5" fill="${o.f?LVC[o.f.level]:'var(--muted)'}">${o.f?o.f.level+' risk':'Not found'}</text>`;});
  return s+'</svg>';}
function recordsByPlatform(){const out={};const add=(arr)=>arr.forEach(x=>{out[x.platform]=(out[x.platform]||0)+1;});
  add(S.locations);add(S.places);add(S.activities);add(uniqContacts(S.contacts));add(S.interests);add(S.identifiers);
  return Object.keys(PL).filter(p=>out[p]).map(p=>[PL[p],out[p]]).sort((a,b)=>b[1]-a[1]);}
function platformBarsSVG(){const d=recordsByPlatform();if(!d.length)return'';const W=460,H=330,L=52,B=34,T=26;const max=Math.max(...d.map(x=>x[1]));
  const mag=Math.pow(10,Math.floor(Math.log10(Math.max(1,max/4))));const step=Math.ceil(max/4/mag)*mag,top=step*4;
  let s=`<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-width:560px;display:block;margin:0 auto" role="img" aria-label="Records found per platform">`;
  for(let i=0;i<=4;i++){const y=T+(H-T-B)*(1-i/4);s+=`<line x1="${L}" x2="${W}" y1="${y}" y2="${y}" stroke="var(--line)" stroke-dasharray="${i?'4 5':'0'}"/><text x="${L-10}" y="${y+4}" text-anchor="end" font-size="11.5" fill="var(--muted)">${fmt(step*i)}</text>`;}
  const slot=(W-L)/d.length,bw=Math.min(90,slot*0.62);
  d.forEach(([name,v],i)=>{const h=(H-T-B)*v/top,x=L+i*slot+(slot-bw)/2,y=H-B-h;
    s+=`<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" rx="6" fill="var(--accent)"><title>${name}: ${fmt(v)} records</title></rect>`;
    s+=`<text x="${(x+bw/2).toFixed(1)}" y="${(y-8).toFixed(1)}" text-anchor="middle" font-size="12.5" font-weight="650" fill="var(--ink)">${fmt(v)}</text><text x="${(x+bw/2).toFixed(1)}" y="${H-12}" text-anchor="middle" font-size="12.5" fill="var(--muted)">${name}</text>`;});
  return s+'</svg>';}
