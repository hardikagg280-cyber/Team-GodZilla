/* Page routing (#dashboard, #upload, ...) and the empty state */
function current(){const h=location.hash.slice(1);return VIEWS.includes(h)?h:'dashboard';}
function go(v){if(location.hash==='#'+v)show();else location.hash=v;}
function show(){let v=current();
  if(!ACC.session){if(v!=='login'&&location.hash)ACC.intended=v;v='login';}else if(v==='login')v='dashboard';
  document.body.classList.toggle('gate',v==='login');renderShell();
  document.querySelectorAll('[data-view]').forEach(s=>s.hidden=s.dataset.view!==v);
  document.querySelectorAll('.navlink').forEach(a=>{if(a.getAttribute('href')==='#'+v)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
  R[v]();
  if(UI.lastView!==v){window.scrollTo(0,0);const a=document.querySelector('.navlink[aria-current]');if(a&&a.scrollIntoView&&innerWidth<860)a.scrollIntoView({inline:'center',block:'nearest'});}
  UI.lastView=v;
  if(UI.scrollTo){const el=document.getElementById(UI.scrollTo);UI.scrollTo=null;if(el){el.open=true;el.scrollIntoView({block:'start'});}}
}
const rerender=()=>R[current()]();

function emptyState(title,text){return `<div class="panel empty"><h2>${title}</h2><p class="muted" style="max-width:56ch">${text}</p>
  <div class="btnrow" style="margin-top:18px"><button class="btn primary" data-act="go" data-v="upload">Upload an archive</button><button class="btn" data-act="demo">Try the demo data</button></div></div>`;}
