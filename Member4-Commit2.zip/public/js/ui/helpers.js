/* Shared UI helpers and page registry */
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const VIEWS=['dashboard','upload','footprint','risks','actions','report','guide','login','admin'];
const LVC={High:'var(--high)',Medium:'var(--med)',Low:'var(--low)'};
const UI={platform:'auto',explPf:'all',explCat:'location',riskF:'all',actF:'remaining',busy:false,status:null,lastView:null,scrollTo:null};
let done=new Set();
try{done=new Set(JSON.parse(localStorage.getItem('privacylens.done')||'[]'));}catch(e){}
function saveDone(){try{localStorage.setItem('privacylens.done',JSON.stringify([...done]));}catch(e){}}
const hasData=()=>S.findings.length>0;
const badge=l=>`<span class="badge lv-${l}">${l}</span>`;
const pfNames=a=>a.map(p=>PL[p]||p).join(', ');
let toastT;
function toast(msg){const t=$('#toast');t.textContent=msg;t.hidden=false;clearTimeout(toastT);toastT=setTimeout(()=>t.hidden=true,3500);}

// Each page file adds its render function to R (R.dashboard, R.upload, ...)
const R={};
