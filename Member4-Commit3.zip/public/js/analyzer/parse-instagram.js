/* Instagram (JSON export): followers, topics, searches, likes, personal info, logins, messages */
function igRecords(d){const out=[];walk(d,o=>{if(!Array.isArray(o)&&(o.string_list_data||o.string_map_data))out.push(o);});return out;}
function parseInstagramJson(pf,lower,d){
  /* Messages (Instagram/Facebook style) — content is never stored */
  if(Array.isArray(d.messages)&&Array.isArray(d.participants)){d.participants.forEach(p=>addContact(pf,decodeIG(p.name),'messaged'));
    for(const m of d.messages)addAct(pf,'message','Message'+(m.sender_name?' from '+decodeIG(m.sender_name):''),m.timestamp_ms);return true;}
  /* Instagram-style records */
  const recs=igRecords(d);
  if(recs.length){
    const base=lower.split('/').pop();const kind=/^followers/.test(base)?'follower':/^following/.test(base)?'following':/close_friends/.test(base)?'close friend':/blocked/.test(base)?'blocked':/^follow/.test(base)?'following':null;
    for(const r of recs){const sl=r.string_list_data||[],sm=r.string_map_data||{};
      if(kind){for(const x of sl)addContact(pf,decodeIG(x.value||r.title),kind,x.timestamp);if(!sl.length&&r.title)addContact(pf,decodeIG(r.title),kind);continue;}
      if(/topic|interest/.test(lower)){addInterest(pf,decodeIG((sm.Name&&sm.Name.value)||(sl[0]&&sl[0].value)||r.title),'Ad topics');continue;}
      if(/search/.test(lower)){addAct(pf,'search',decodeIG((sm.Search&&sm.Search.value)||(sl[0]&&sl[0].value)||r.title),(sm.Time&&sm.Time.timestamp)||(sl[0]&&sl[0].timestamp));continue;}
      if(/personal_information|profile_information/.test(lower)){for(const k in sm){const kl=k.toLowerCase(),v=sm[k]&&sm[k].value;
          const type=kl.includes('email')?'Email':kl.includes('phone')?'Phone number':kl.includes('birth')?'Birth date':kl==='name'?'Name':kl==='username'?'Username':kl.includes('gender')?'Gender':null;
          if(type&&v)addId(pf,type,decodeIG(v));}continue;}
      if(/login|logout|account_activity|password_change/.test(lower)){for(const k in sm)if(/ip/i.test(k)&&sm[k]&&sm[k].value)addId(pf,'IP address',sm[k].value);
        addAct(pf,'login','Account login',(sm.Time&&sm.Time.timestamp)||r.title);continue;}
      const type=/like/.test(lower)?'like':/comment/.test(lower)?'comment':/stor(y|ies)/.test(lower)?'story':/post|media/.test(lower)?'post':/saved/.test(lower)?'save':'activity';
      const t=(sl[0]&&sl[0].timestamp)||Object.values(sm).map(x=>x&&x.timestamp).find(Boolean);
      if(t)addAct(pf,type,decodeIG(r.title||(sl[0]&&sl[0].value)||''),t);}
  }
  if(Array.isArray(d.label_values)){for(const lv of d.label_values){const vals=(lv.vec||[]).map(x=>x.value).concat(lv.value?[lv.value]:[]);
      for(const v of vals){if(/location/i.test(lv.label||'')||/location/.test(lower))addPlace(pf,decodeIG(v));else addInterest(pf,decodeIG(v),lv.label||'Interests');}}}
  return !!(recs.length||d.label_values);
}
