/* Spotify: streaming history, searches, ad inferences, account data, follows */
function parseSpotifyJson(pf,lower,d){

  if(Array.isArray(d)&&d.length&&d[0]&&typeof d[0]==='object'){const f=d[0];
    if('endTime' in f&&('trackName' in f||'episodeName' in f)){for(const r of d)addAct(pf,'listen',(r.trackName||r.episodeName||'')+' — '+(r.artistName||r.episodeShowName||''),r.endTime,r.artistName||r.episodeShowName);return true;}
    if('ts' in f&&('master_metadata_track_name' in f||'episode_name' in f||'ms_played' in f)){
      for(const r of d){const who=r.master_metadata_album_artist_name||r.episode_show_name;addAct(pf,'listen',(r.master_metadata_track_name||r.episode_name||'Unknown')+' — '+(who||''),r.ts,who);
        if(r.ip_addr||r.ip_addr_decrypted)addId(pf,'IP address',r.ip_addr||r.ip_addr_decrypted);if(r.conn_country)addId(pf,'Country',r.conn_country);}return true;}
    if('searchQuery' in f){for(const r of d)addAct(pf,'search',r.searchQuery,r.searchTime);return true;}}
  if(Array.isArray(d.inferences)){d.inferences.forEach(x=>addInterest(pf,cleanInference(x),'Ad inferences'));return true;}
  if(!Array.isArray(d)&&(('email' in d&&('birthdate' in d||'country' in d))||'mobileNumber' in d)){
    const map={email:'Email',birthdate:'Birth date',postalCode:'Postal code',mobileNumber:'Phone number',username:'Username',country:'Country',gender:'Gender'};
    for(const k in map)if(d[k])addId(pf,map[k],d[k]);return true;}
  if(Array.isArray(d.userIsFollowing)||Array.isArray(d.userIsFollowedBy)){(d.userIsFollowing||[]).forEach(n=>addContact(pf,n,'following'));(d.userIsFollowedBy||[]).forEach(n=>addContact(pf,n,'follower'));return true;}
  return false;
}
