#!/usr/bin/env node
// Commits one member's 10 parts of the PrivacyLens website, one commit per feature,
// using that member's own Git name and email.
//
// Usage:  node commit-my-part.js <member number 1-4> <path to your Team-GodZilla clone>
// Then:   git -C <path> push
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const [memberArg, repoArg] = process.argv.slice(2);
const member = Number(memberArg);
if (![1, 2, 3, 4].includes(member) || !repoArg) {
  console.log("Usage: node commit-my-part.js <member number 1-4> <path to your Team-GodZilla clone>");
  process.exit(1);
}
const repo = path.resolve(repoArg);
const source = path.join(__dirname, "Team-GodZilla");
const plan = JSON.parse(fs.readFileSync(path.join(__dirname, "plan.json"), "utf8"));
const git = (...args) => execFileSync("git", args, { cwd: repo, encoding: "utf8" }).trim();
const gitQuiet = (...args) => { try { return git(...args); } catch { return null; } };

if (!fs.existsSync(path.join(repo, ".git"))) {
  console.log(`“${repo}” isn’t a Git repository. Clone it first:\n  git clone https://github.com/hardikagg280-cyber/Team-GodZilla.git`);
  process.exit(1);
}
const name = gitQuiet("config", "user.name"), email = gitQuiet("config", "user.email");
if (!name || !email) {
  console.log('Set your Git name and GitHub email first:\n  git config --global user.name "Your Name"\n  git config --global user.email "your-github-email@example.com"');
  process.exit(1);
}
if (gitQuiet("status", "--porcelain")) {
  console.log("Your clone has uncommitted changes. Commit or discard them, then run this again.");
  process.exit(1);
}
console.log(`Committing as ${name} <${email}>`);
if (gitQuiet("ls-remote", "--heads", "origin")) {
  console.log("Getting the latest changes from GitHub…");
  git("pull", "--rebase");
}

const mine = plan.find((p) => p.member === member);
const allFiles = new Set(plan.flatMap((p) => p.commits.flatMap((c) => c.files)));
let made = 0;
mine.commits.forEach((c, i) => {
  let message = c.message;
  if (member === 1 && i === 0) {
    // Remove files left over from earlier versions of the website.
    const old = (gitQuiet("ls-files") || "").split("\n").filter((f) => f && !allFiles.has(f));
    if (old.length) {
      git("rm", "-q", "--", ...old);
      message += " and remove old files";
    }
  }
  for (const f of c.files) {
    const to = path.join(repo, f);
    fs.mkdirSync(path.dirname(to), { recursive: true });
    fs.copyFileSync(path.join(source, f), to);
  }
  git("add", "--", ...c.files);
  if (!gitQuiet("diff", "--cached", "--name-only")) {
    console.log(`  skipped ${i + 1}/10 (already up to date): ${c.message}`);
    return;
  }
  git("commit", "-q", "-m", message);
  made++;
  console.log(`  ✓ ${i + 1}/10 ${message}`);
});
console.log(`\nDone: ${made} commits for Member ${member}. Now send them to GitHub:\n  git -C "${repoArg}" push`);
