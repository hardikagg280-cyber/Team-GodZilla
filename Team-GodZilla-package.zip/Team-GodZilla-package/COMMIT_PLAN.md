# Team GodZilla · commit plan

40 commits, 10 per member. Each commit adds one feature of the PrivacyLens website, so every member's work shows on their own GitHub profile.

Repository: https://github.com/hardikagg280-cyber/Team-GodZilla

## Before you start (every member)

1. Hardik adds the other three as collaborators: repository **Settings → Collaborators → Add people**. Each member accepts the email invite.
2. Install **Git** (https://git-scm.com) and **Node.js** (https://nodejs.org).
3. Set your own name and the email of **your** GitHub account (this is what links the commits to your profile):

```
git config --global user.name "Your Name"
git config --global user.email "your-github-email@example.com"
```

4. Clone the repository and unzip this package next to it:

```
git clone https://github.com/hardikagg280-cyber/Team-GodZilla.git
```

## Order

**Member 1 goes first** (setup and layout). After that, Members 2, 3 and 4 can commit in any order. The website works fully once all 40 commits are in.

## Option A: run the helper script (does your 10 commits for you)

From the folder that contains this file, run (replace the number with **your** member number and the path with your clone):

```
node commit-my-part.js 1 ../Team-GodZilla
git -C ../Team-GodZilla push
```

The script pulls the latest changes, copies in your files one commit at a time and commits each with its message, using your own Git name and email. Then you push. Member 1’s first commit also removes old files from earlier versions of the site.

## Option B: do it by hand

For each commit in your list: copy the listed files from `Team-GodZilla/` in this package into the same place in your clone, then run:

```
git pull --rebase
git add <the files>
git commit -m "<the message>"
```

Push when all 10 are done: `git push`.

## Member 1: Project setup, layout & design

| # | Commit message | Files |
| --- | --- | --- |
| 1 | Add project README | `README.md` |
| 2 | Set up npm project and gitignore | `.gitignore`<br>`package.json` |
| 3 | Add Netlify configuration | `netlify.toml` |
| 4 | Add main page layout and navigation | `public/index.html` |
| 5 | Add design tokens, typography and base components | `public/css/base.css` |
| 6 | Add mobile layout and reduced-motion styles | `public/css/responsive.css` |
| 7 | Style the dashboard | `public/css/dashboard.css` |
| 8 | Style the upload and footprint pages | `public/css/upload.css`<br>`public/css/explorer.css` |
| 9 | Add shared UI helpers | `public/js/ui/helpers.js` |
| 10 | Add page routing and empty states | `public/js/ui/router.js` |

## Member 2: Data parsing & sample data

| # | Commit message | Files |
| --- | --- | --- |
| 1 | Add JSZip for reading ZIP archives | `public/js/vendor/jszip.min.js` |
| 2 | Add analysis state and record helpers | `public/js/analyzer/state.js` |
| 3 | Read JSON, VCF, CSV and HTML files from archives | `public/js/analyzer/parse-files.js` |
| 4 | Parse Google Takeout data | `public/js/analyzer/parse-google.js` |
| 5 | Parse Instagram data | `public/js/analyzer/parse-instagram.js` |
| 6 | Parse Spotify data | `public/js/analyzer/parse-spotify.js` |
| 7 | Add built-in demo data | `public/js/demo-data.js` |
| 8 | Add sample Google Takeout export | `public/sample-data/google-takeout-demo.zip` |
| 9 | Add sample Instagram export | `public/sample-data/instagram-demo.zip` |
| 10 | Add sample Spotify export | `public/sample-data/spotify-demo.zip` |

## Member 3: Risk engine, charts & pages

| # | Commit message | Files |
| --- | --- | --- |
| 1 | Add risk scoring engine | `public/js/analyzer/risk-engine.js` |
| 2 | Add privacy action library | `public/js/analyzer/action-library.js` |
| 3 | Add score ring, risk radar and platform charts | `public/js/charts/score-charts.js` |
| 4 | Build the dashboard page | `public/js/pages/dashboard.js` |
| 5 | Build the upload and analyze page | `public/js/pages/upload.js` |
| 6 | Add location plot, timeline and heatmap charts | `public/js/charts/footprint-charts.js` |
| 7 | Build the digital footprint explorer | `public/js/pages/footprint.js` |
| 8 | Build the risk analyzer page | `public/js/pages/risks.js`<br>`public/css/risks-actions.css` |
| 9 | Build the action plan page | `public/js/pages/actions.js` |
| 10 | Add the help and data download guide | `public/js/pages/guide.js`<br>`public/css/guide-report.css` |

## Member 4: Accounts, admin, backend & reports

| # | Commit message | Files |
| --- | --- | --- |
| 1 | Add API response helpers | `netlify/functions/lib/http.mjs` |
| 2 | Add password hashing and sign-in tokens | `netlify/functions/lib/auth.mjs` |
| 3 | Add user and result storage helpers | `netlify/functions/lib/store.mjs` |
| 4 | Add accounts and admin API | `netlify/functions/api.mjs` |
| 5 | Add sessions and API client | `public/js/account/session.js`<br>`public/css/account.css` |
| 6 | Add sign-in and sign-up page | `public/js/account/login.js` |
| 7 | Save result summaries to accounts | `public/js/account/results.js` |
| 8 | Add admin page | `public/js/account/admin.js` |
| 9 | Add privacy report page | `public/js/vendor/jspdf.umd.min.js`<br>`public/js/pages/report.js` |
| 10 | Add PDF and JSON export and start the app | `public/js/report/export.js`<br>`public/js/main.js` |

## After all 40 commits

If the Netlify site is connected to this repository, it redeploys automatically. If you deployed from VS Code before, run `npx netlify deploy --prod` from the repository folder once.
