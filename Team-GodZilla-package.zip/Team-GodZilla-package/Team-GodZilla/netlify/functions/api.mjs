// Accounts and admin API (Netlify Function). Data is stored in Netlify Blobs.
import { getStore } from "@netlify/blobs";
import { json, fail } from "./lib/http.mjs";
import { hashPassword, newSalt, sameText, signingKey, sign, verify } from "./lib/auth.mjs";
import { userKey, resultKey, publicUser, num, allUsers } from "./lib/store.mjs";

export async function handle(req, store) {
  const path = new URL(req.url).pathname.replace(/^\/api/, "") || "/";
  const method = req.method;
  const body = method === "POST" ? await req.json().catch(() => ({})) : {};
  const key = await signingKey(store);
  const token = verify((req.headers.get("authorization") || "").replace(/^Bearer\s+/i, ""), key);
  const me = token ? await store.get(userKey(token.u), { type: "json" }) : null;
  const issue = (u) => sign({ u: u.username, exp: Date.now() + 30 * 864e5 }, key);

  // ----- public -----
  if (path === "/register" && method === "POST") {
    const username = String(body.username || "").trim();
    const password = String(body.password || "");
    if (!/^[A-Za-z0-9_.-]{3,40}$/.test(username)) return fail("Usernames are 3–40 characters: letters, numbers, dots, dashes or underscores.");
    if (password.length < 6) return fail("Use a password with at least 6 characters.");
    if (await store.get(userKey(username))) return fail("That username is taken. Pick another one.", 409);
    const first = (await store.list({ prefix: "users/" })).blobs.length === 0;
    const salt = newSalt();
    const user = { username, salt, hash: hashPassword(password, salt), isAdmin: first, createdAt: Date.now() };
    await store.setJSON(userKey(username), user);
    return json({ token: issue(user), user: publicUser(user) });
  }
  if (path === "/login" && method === "POST") {
    const user = await store.get(userKey(String(body.username || "").trim()), { type: "json" });
    if (!user || !sameText(hashPassword(String(body.password || ""), user.salt), user.hash))
      return fail("That username and password don’t match. Check them and try again.", 401);
    return json({ token: issue(user), user: publicUser(user) });
  }
  if (path === "/notice" && method === "GET") return json({ notice: (await store.get("config/notice")) || "" });

  // ----- signed in -----
  if (!me) return fail("Sign in first.", 401);
  if (path === "/me") return json({ user: publicUser(me) });
  if (path === "/results" && method === "POST") {
    const prev = await store.get(resultKey(me.username), { type: "json" });
    const lv = ["High exposure", "Moderate exposure", "Well protected"];
    const okPf = ["google", "instagram", "spotify", "other"];
    await store.setJSON(resultKey(me.username), {
      runs: ((prev && prev.runs) || 0) + 1, lastAt: Date.now(), score: num(body.score),
      rating: lv.includes(body.rating) ? body.rating : "", platforms: (Array.isArray(body.platforms) ? body.platforms : []).filter((p) => okPf.includes(p)),
      high: num(body.high), medium: num(body.medium), low: num(body.low),
      actionsDone: num(body.actionsDone), actionsTotal: num(body.actionsTotal), demo: !!body.demo,
    });
    return json({ ok: true });
  }
  if (path === "/results/progress" && method === "POST") {
    const prev = await store.get(resultKey(me.username), { type: "json" });
    if (prev) await store.setJSON(resultKey(me.username), { ...prev, actionsDone: num(body.actionsDone), actionsTotal: num(body.actionsTotal) });
    return json({ ok: true });
  }

  // ----- admins only -----
  if (!me.isAdmin) return fail("Only admins can do that.", 403);
  if (path === "/notice" && method === "POST") {
    await store.set("config/notice", String(body.text || "").trim().slice(0, 400));
    return json({ ok: true });
  }
  if (path === "/admin" && method === "GET") {
    const users = await allUsers(store);
    const rows = await Promise.all(users.map(async (u) => ({ ...publicUser(u), result: await store.get(resultKey(u.username), { type: "json" }) })));
    return json({ users: rows });
  }
  if (path === "/admin/user" && method === "POST") {
    const target = await store.get(userKey(body.username), { type: "json" });
    if (!target) return fail("That user doesn’t exist.", 404);
    const self = target.username.toLowerCase() === me.username.toLowerCase();
    if (body.action === "make_admin") {
      await store.setJSON(userKey(target.username), { ...target, isAdmin: true });
    } else if (body.action === "remove_admin") {
      const admins = (await allUsers(store)).filter((u) => u.isAdmin).length;
      if (self && admins <= 1) return fail("You’re the only admin, so you can’t remove your own admin access.");
      await store.setJSON(userKey(target.username), { ...target, isAdmin: false });
    } else if (body.action === "delete") {
      if (self) return fail("You can’t delete your own account.");
      await store.delete(userKey(target.username));
      await store.delete(resultKey(target.username));
    } else return fail("Unknown action.");
    return json({ ok: true });
  }
  return fail("Not found.", 404);
}

export default async (req) => {
  try {
    return await handle(req, getStore({ name: "footprints", consistency: "strong" }));
  } catch (e) {
    console.error(e);
    return fail("Something went wrong on the server. Try again.", 500);
  }
};

export const config = { path: "/api/*" };
