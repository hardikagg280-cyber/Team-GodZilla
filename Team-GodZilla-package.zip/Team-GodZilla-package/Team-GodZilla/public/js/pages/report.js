/* Privacy report page */
function summaryLines(){const L=[];const loc=S.findings.find(f=>f.cat==='location');S.findings.forEach(f=>L.push(`${f.title}: ${f.detected}`));return L;}
R.report=()=>{const el=$('[data-view="report"]');
  if(!hasData()){el.innerHTML=`<h1>Your privacy report.</h1><p class="lede">A complete summary you can download once an analysis is done.</p>${emptyState('No report yet','Upload an archive or load the demo data.')}`;return;}
  const pfs=uniq(S.archives.map(a=>a.platform));const nDone=S.actions.filter(a=>done.has(a.id)).length;
  el.innerHTML=`<h1>Your privacy report.</h1><p class="lede">Everything from this audit on one page. Download it as a PDF or export a summary file.</p>
  <div class="btnrow" style="margin-bottom:22px"><button class="btn primary" data-act="pdf">Download report (PDF)</button><button class="btn" data-act="json">Export summary (JSON)</button><button class="btn" data-act="reset">Start a new analysis</button></div>
  <div class="panel"><div class="report-head"><div><h2 style="margin:0">PrivacyLens report</h2><p class="muted small" style="margin:4px 0 0">${new Date().toLocaleDateString(undefined,{dateStyle:'long'})}${S.demo?' · Demo data':''}</p></div>
    <div style="text-align:right"><div class="big">${S.score}<span class="muted" style="font-size:20px">/100</span></div><div class="small">${scoreLabel(S.score)}</div></div></div>
    <div class="kv"><div><b>${pfs.length}</b><span>Platforms: ${pfNames(pfs)}</span></div><div><b>${S.findings.length}</b><span>Data categories identified</span></div><div><b>${S.findings.filter(f=>f.level==='High').length}</b><span>High-risk findings</span></div><div><b>${nDone}/${S.actions.length}</b><span>Actions completed</span></div></div>
    <h2 style="margin-top:28px">Digital footprint summary</h2><ul style="margin:0;padding-left:20px">${summaryLines().map(l=>`<li style="margin:5px 0">${esc(l)}</li>`).join('')}</ul>
    <h2 style="margin-top:28px">Findings</h2><div class="tbl"><table><thead><tr><th>Privacy concern</th><th>Risk</th><th>Why it matters</th></tr></thead><tbody>${S.findings.map(f=>`<tr><td>${esc(f.title)}</td><td>${badge(f.level)}</td><td>${esc(f.why)}</td></tr>`).join('')}</tbody></table></div>
    <h2 style="margin-top:28px">Recommended actions</h2><div class="tbl"><table><thead><tr><th>Action</th><th>Priority</th><th>Status</th></tr></thead><tbody>${S.actions.map(a=>`<tr><td>${esc(a.title)}</td><td>${badge(a.priority)}</td><td>${done.has(a.id)?'Done':'Pending'}</td></tr>`).join('')}</tbody></table></div></div>`;};
