/* Help & data guide page */
R.guide=()=>{const el=$('[data-view="guide"]');if(el.dataset.ready)return;el.dataset.ready='1';
  el.innerHTML=`<h1>Where do I get my data?</h1><p class="lede">Every major platform lets you download a copy of what it stores about you. Here’s how to get the files PrivacyLens reads. Menu names change from time to time, so look for the closest match.</p>
  <div class="stack">
  <div class="panel"><h2>What is a digital footprint?</h2><p style="max-width:66ch">It’s the trail of data you leave while using online services: where you go, what you search, watch and play, who you follow and what platforms guess about you. Each company sees only its part, but each part can be surprisingly detailed.</p>
    <h2 style="margin-top:20px">Why analyze it?</h2><p style="max-width:66ch;margin:0">Export files are huge and hard to read. Seeing them laid out shows what’s actually stored, which parts are risky, and which settings to change so less is collected in future.</p></div>
  <div class="panel">
  <details id="g-google"><summary>How to download data from Google</summary><ol class="guide-steps">
    <li>Open <a href="https://takeout.google.com/" target="_blank" rel="noopener noreferrer">takeout.google.com</a> and sign in.</li>
    <li>Click <b>Deselect all</b>, then select Location History (Timeline), My Activity, YouTube and YouTube Music, Contacts and Profile.</li>
    <li>For My Activity, open <b>Multiple formats</b> and set Activity records to <b>JSON</b>.</li>
    <li>Click <b>Next step</b>, choose “Send download link via email”, “Export once”, <b>.zip</b> and 2 GB.</li>
    <li>Click <b>Create export</b>. When the email arrives (minutes to a few days), download the ZIP and upload it here.</li></ol>
    <p class="muted small">Google now keeps Timeline on your phone for many accounts. To include it, export Timeline from your phone’s location settings, put the Timeline.json file in a ZIP and upload that too.</p></details>
  <details id="g-instagram"><summary>How to download Instagram data</summary><ol class="guide-steps">
    <li>Go to your profile, open the menu and tap <b>Accounts Center</b>.</li>
    <li>Tap <b>Your information and permissions</b> → <b>Download your information</b> → <b>Download or transfer information</b>.</li>
    <li>Choose your Instagram account, then <b>All available information</b> or pick Followers and following, Personal information, Ads information, Logged information and Your activity.</li>
    <li>Choose <b>Download to device</b>, date range <b>All time</b> and format <b>JSON</b>. HTML exports can’t be analyzed.</li>
    <li>Tap <b>Create files</b>. You’ll get a notification when it’s ready, usually within a few days. Download the ZIP and upload it here.</li></ol></details>
  <details id="g-spotify"><summary>How to request Spotify data</summary><ol class="guide-steps">
    <li>On a computer, sign in at spotify.com and open <b>Account</b> → <b>Privacy settings</b>.</li>
    <li>Under Download your data, check <b>Account data</b> (fastest). Extended streaming history is optional and takes longer.</li>
    <li>Click <b>Request data</b> and confirm the email Spotify sends you.</li>
    <li>When the “your data is ready” email arrives, usually within a few days, download the ZIP and upload it here.</li></ol></details>
  </div>
  <div class="panel"><h2>Supported files</h2><div class="tbl"><table><thead><tr><th>Platform</th><th>Files PrivacyLens reads</th></tr></thead><tbody>
    <tr><td>Google</td><td>Records.json, Semantic Location History, Timeline.json, My Activity (JSON or HTML), YouTube watch and search history, Chrome BrowserHistory.json, Contacts (.vcf), Profile.json</td></tr>
    <tr><td>Instagram (JSON)</td><td>Followers and following, your topics and ad interests, locations of interest, recent searches, likes, personal information, login activity, message metadata</td></tr>
    <tr><td>Spotify</td><td>StreamingHistory*.json, extended streaming history, SearchQueries.json, Inferences.json, Userdata.json, Follow.json</td></tr>
    <tr><td>Other ZIPs</td><td>Any JSON with coordinates or timestamps is scanned for locations and activity</td></tr></tbody></table></div>
    <p class="muted small" style="margin:10px 0 0">Photos, videos and files over 80 MB inside the archive are skipped. Message text is never read or stored, only who and when.</p></div>
  <div class="panel"><h2>Frequently asked questions</h2>
    <details><summary>Is my data uploaded anywhere?</summary><p>No. The ZIP is opened inside this browser tab. Nothing is sent to a server, and the analysis is cleared when you close or reload the page. Only your ticked actions are remembered on this device.</p></details>
    <details><summary>How is the privacy score calculated?</summary><p>Each data category found adds to your exposure based on its risk level: high risks count most, low risks least. 100 means nothing risky was found.</p></details>
    <details><summary>Does PrivacyLens delete anything for me?</summary><p>No. It tells you what to delete, restrict or lock down and links to the right setting, but you stay in control of every change.</p></details>
    <details><summary>My Instagram ZIP shows no data. Why?</summary><p>It was probably exported in HTML format. Request a new export and choose JSON.</p></details>
    <details><summary>The export is very large. What should I do?</summary><p>Select only the categories listed above when requesting the export. Smaller ZIPs analyze much faster.</p></details>
    <details><summary>Can I analyze several platforms together?</summary><p>Yes. Upload one ZIP per platform. Results are combined across all of them.</p></details>
  </div></div>`;};
