/* Analysis state, timestamps and record helpers shared by all parsers */
const PL={google:'Google',instagram:'Instagram',spotify:'Spotify',other:'Other'};
const CATS=[
  {id:'location',name:'Location data'},
  {id:'search',name:'Search history'},
  {id:'activity',name:'Activity patterns'},
  {id:'contacts',name:'Contacts & connections'},
  {id:'interests',name:'Interests & preferences'},
  {id:'identifiers',name:'Personal identifiers'}];
const LV={High:3,Medium:2,Low:1};
let S;
function fresh(){S={archives:[],locations:[],places:[],activities:[],contacts:[],interests:[],identifiers:[],findings:[],actions:[],score:null,demo:false};}
fresh();

const NOW=Date.now();
function toMs(v){
  if(v==null||v==='')return null;
  if(typeof v==='number'){if(!isFinite(v)||v<=0)return null;return v<1e11?v*1000:(v>1e14?v/1000:v);}
  if(typeof v==='string'){let s=v.trim();
    if(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(s))s=s.replace(' ','T')+':00Z';
    else if(/^\d+$/.test(s))return toMs(Number(s));
    const m=Date.parse(s);return isNaN(m)?null:m;}
  return null;
}
const validT=t=>(t&&t>946684800000&&t<NOW+864e5)?t:null;
const total=()=>S.locations.length+S.places.length+S.activities.length+S.contacts.length+S.interests.length+S.identifiers.length;
function decodeIG(s){if(typeof s!=='string')return s;try{return /[\u00c0-\u00ff]/.test(s)?decodeURIComponent(escape(s)):s;}catch(e){return s;}}

function addAct(pf,type,text,t,who){if(S.activities.length>=150000)return;S.activities.push({platform:pf,type,text:text?String(text).slice(0,160):'',t:validT(toMs(t)),who:who||''});}
function addLoc(pf,lat,lng,t,name,src){if(S.locations.length>=80000)return;lat=+lat;lng=+lng;
  if(!isFinite(lat)||!isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180||(lat===0&&lng===0))return;
  S.locations.push({platform:pf,lat,lng,t:validT(toMs(t)),name:name||'',src:src||''});}
function addPlace(pf,name){if(name&&!S.places.some(p=>p.platform===pf&&p.name===name))S.places.push({platform:pf,name:String(name).slice(0,90)});}
function addContact(pf,name,kind,t){if(!name)return;S.contacts.push({platform:pf,name:String(name).slice(0,80),kind,t:validT(toMs(t))});}
function addInterest(pf,label,source){if(!label)return;label=String(label).trim().slice(0,80);if(!label)return;S.interests.push({platform:pf,label,source:source||'Interests'});}
function addId(pf,type,value){if(value==null)return;value=String(value).trim();if(!value)return;
  if(S.identifiers.some(x=>x.type===type&&x.value===value&&x.platform===pf))return;
  if(S.identifiers.filter(x=>x.type===type&&x.platform===pf).length>=40)return;
  S.identifiers.push({platform:pf,type,value});}
function parseLatLng(s){if(typeof s!=='string')return[NaN,NaN];const m=s.replace(/[°\s]/g,'').split(',');return[parseFloat(m[0]),parseFloat(m[1])];}
function walk(root,fn,limit){limit=limit||300000;const st=[root];let n=0;
  while(st.length&&n<limit){const o=st.pop();n++;if(o&&typeof o==='object'){fn(o);for(const k in o){const v=o[k];if(v&&typeof v==='object')st.push(v);}}}}
const cleanInference=x=>String(x).replace(/^(1P|3P)_(Custom_)?/,'').replace(/_/g,' ').trim();

function detectPlatform(paths){const j=paths.join('\n').toLowerCase();
  if(/(^|\n)takeout\//.test(j)||/my activity\/|location history|timeline\.json|youtube and youtube music/.test(j))return'google';
  if(/streaminghistory|streaming_history|userdata\.json|spotify|inferences\.json/.test(j))return'spotify';
  if(/followers_and_following|your_instagram_activity|personal_information\/|instagram/.test(j))return'instagram';
  return null;}
