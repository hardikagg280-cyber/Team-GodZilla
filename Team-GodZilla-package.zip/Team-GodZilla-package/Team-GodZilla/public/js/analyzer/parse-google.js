/* Google Takeout: location history, Timeline, My Activity, YouTube, Chrome, profile */
function parseGoogleJson(pf,lower,d){

  if(Array.isArray(d.locations)&&d.locations.length&&d.locations[0]&&('latitudeE7' in d.locations[0]||'latitude' in d.locations[0])){
    for(const r of d.locations)addLoc(pf,r.latitudeE7!=null?r.latitudeE7/1e7:r.latitude,r.longitudeE7!=null?r.longitudeE7/1e7:r.longitude,r.timestamp||r.timestampMs,'','record');return true;}
  if(Array.isArray(d.timelineObjects)){for(const o of d.timelineObjects){const v=o.placeVisit;
      if(v&&v.location){const L=v.location,t=v.duration&&(v.duration.startTimestamp||v.duration.startTimestampMs);
        if(L.latitudeE7!=null)addLoc(pf,L.latitudeE7/1e7,L.longitudeE7/1e7,t,L.name||L.address||'','visit');else if(L.name)addPlace(pf,L.name);}
      const a=o.activitySegment;if(a&&a.startLocation&&a.startLocation.latitudeE7!=null)addLoc(pf,a.startLocation.latitudeE7/1e7,a.startLocation.longitudeE7/1e7,a.duration&&(a.duration.startTimestamp||a.duration.startTimestampMs),'','route');}return true;}
  if(Array.isArray(d.semanticSegments)||Array.isArray(d.rawSignals)){
    for(const s of d.semanticSegments||[]){const tc=s.visit&&s.visit.topCandidate,ll=tc&&tc.placeLocation&&tc.placeLocation.latLng;
      if(ll){const p=parseLatLng(ll);addLoc(pf,p[0],p[1],s.startTime,'','visit');}
      if(Array.isArray(s.timelinePath))for(const q of s.timelinePath.slice(0,40)){const p=parseLatLng(q.point);addLoc(pf,p[0],p[1],q.time,'','path');}}
    for(const r of d.rawSignals||[]){const p=r.position;if(p&&p.LatLng){const q=parseLatLng(p.LatLng);addLoc(pf,q[0],q[1],p.timestamp,'','raw');}}return true;}
  // My Activity, YouTube, Chrome and profile
  if(Array.isArray(d)&&d.length&&d[0]&&typeof d[0]==='object'&&'title' in d[0]&&'time' in d[0]&&('header' in d[0]||'products' in d[0])){
    for(const it of d)googleAct(pf,lower,it.title,it.time,(it.subtitles&&it.subtitles[0]&&it.subtitles[0].name)||it.header);return true;}
  if(Array.isArray(d['Browser History'])){for(const b of d['Browser History'])addAct(pf,'browse',b.title||b.url,b.time_usec);return true;}
  if(/profile\/profile\.json$/.test(lower)){(d.emails||[]).forEach(e=>addId(pf,'Email',e.value));if(d.birthday)addId(pf,'Birth date',d.birthday);if(d.displayName)addId(pf,'Name',d.displayName);
    (d.phoneNumbers||[]).forEach(p=>addId(pf,'Phone number',p.value||p));return true;}
  return false;
}
