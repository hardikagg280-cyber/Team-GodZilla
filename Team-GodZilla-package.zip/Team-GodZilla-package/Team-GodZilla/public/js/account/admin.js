/* Admin page: users, statistics, roles and site notice */
async function saveNotice(clear){const ta=$('#notice-text');const text=clear?'':(ta?ta.value.trim().slice(0,400):'');
  try{await api('/notice',{method:'POST',body:{text}});ACC.notice=text;renderNotice();if(clear&&ta)ta.value='';toast(clear?'Notice removed':'Notice published to all users');}
  catch(e){toast(e.message);}}
async function loadAdmin(){ACC.recErr=null;try{const d=await api('/admin');ACC.records=d.users;}catch(e){ACC.recErr=e.message;}if(current()==='admin')R.admin();}
async function manageUser(username,action){if(action==='delete'&&!confirm(`Delete ${username}’s account and results?`))return;
  try{await api('/admin/user',{method:'POST',body:{username,action}});toast(action==='delete'?'Deleted '+username:action==='make_admin'?username+' is now an admin':username+' is no longer an admin');loadAdmin();}
  catch(e){toast(e.message);}}
R.admin=()=>{const el=$('[data-view="admin"]');
  const msg=t=>{el.dataset.mode='msg';el.innerHTML=`<h1>Admin</h1><p class="lede">${t}</p>`;};
  if(!ACC.ready)return msg('Checking your access…');
  if(!(ACC.user&&ACC.user.isAdmin&&ACC.session==='account'))return msg('This page is only for admins. Ask an admin of this site to give your account admin access.');
  if(el.dataset.mode!=='admin'){el.dataset.mode='admin';ACC.records=null;
    el.innerHTML=`<div class="toolbar"><h1>Admin</h1><button class="btn" data-act="admin-refresh">Refresh</button></div><p class="lede">Everyone with an account on this site and their latest results. You see summaries only: scores, risk counts and progress. Archives never leave a person’s device.</p>
      <div class="stack"><div id="admin-stats"></div>
      <div class="panel"><h2>Notice for all users</h2><p class="muted small">Shown at the top of every page for everyone who opens the site.</p>
        <label for="notice-text" class="sr">Notice text</label><textarea id="notice-text" rows="3" maxlength="400" placeholder="For example: Demo day is on Friday. Try the action plan before then!">${esc(ACC.notice)}</textarea>
        <div class="btnrow" style="margin-top:12px"><button class="btn primary" data-act="save-notice">Publish notice</button><button class="btn" data-act="clear-notice">Remove notice</button></div></div></div>`;
    loadAdmin();}
  const box=$('#admin-stats');const users=ACC.records;
  if(users==null){box.innerHTML=`<div class="panel"><p class="muted" style="margin:0">${esc(ACC.recErr||'Loading users…')}</p></div>`;return;}
  const recs=users.filter(u=>u.result);const n=Math.max(1,recs.length);
  const runs=recs.reduce((s,u)=>s+(u.result.runs||1),0),avg=recs.length?Math.round(recs.reduce((s,u)=>s+(u.result.score||0),0)/recs.length):0;
  const tDone=recs.reduce((s,u)=>s+(u.result.actionsDone||0),0),tAll=recs.reduce((s,u)=>s+(u.result.actionsTotal||0),0);
  const pc={};recs.forEach(u=>(u.result.platforms||[]).forEach(p=>pc[p]=(pc[p]||0)+1));
  const rc={'High exposure':0,'Moderate exposure':0,'Well protected':0};recs.forEach(u=>{if(u.result.rating in rc)rc[u.result.rating]++;});
  const rcol={'High exposure':'var(--high)','Moderate exposure':'var(--med)','Well protected':'var(--low)'};
  const rows=users.slice().sort((a,b)=>((b.result&&b.result.lastAt)||b.createdAt)-((a.result&&a.result.lastAt)||a.createdAt));
  const me=ACC.user.username.toLowerCase();
  box.innerHTML=`<div class="stack"><div class="panel"><div class="stats" style="border:0;margin:0;padding:0">
      <div class="stat"><b>${users.length}</b><span>Registered users</span></div><div class="stat"><b>${fmt(runs)}</b><span>Analyses run</span></div>
      <div class="stat"><b>${avg}</b><span>Average privacy score</span></div><div class="stat"><b>${tAll?Math.round(tDone/tAll*100):0}%</b><span>Actions completed</span></div></div></div>
    <div class="cols"><div class="panel"><h2>Platforms analyzed</h2>${Object.keys(PL).filter(p=>pc[p]).map(p=>`<div class="bar-row"><span>${PL[p]}</span><div class="track"><i style="width:${pc[p]/n*100}%;background:var(--accent)"></i></div><span class="num">${pc[p]} user${pc[p]===1?'':'s'}</span></div>`).join('')||'<p class="muted">No results yet.</p>'}</div>
      <div class="panel"><h2>Exposure levels</h2>${Object.keys(rc).map(k=>`<div class="bar-row"><span>${k}</span><div class="track"><i style="width:${rc[k]/n*100}%;background:${rcol[k]}"></i></div><span class="num">${rc[k]} user${rc[k]===1?'':'s'}</span></div>`).join('')}</div></div>
    <div class="panel"><h2>People</h2><div class="tbl"><table><thead><tr><th>User</th><th>Role</th><th>Last analysis</th><th class="n">Score</th><th>Risks (H/M/L)</th><th>Platforms</th><th class="n">Actions done</th><th>Manage</th></tr></thead><tbody>
      ${rows.map(u=>{const r=u.result,self=u.username.toLowerCase()===me;return `<tr><td>${esc(u.username)}${self?' <span class="muted small">(you)</span>':''}${r&&r.demo?' <span class="chip" style="padding:1px 8px;font-size:12px">demo</span>':''}</td>
        <td>${u.isAdmin?'Admin':'Member'}</td><td>${r?new Date(r.lastAt).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'}):'No analysis yet'}</td>
        <td class="n">${r?r.score:'—'}</td><td>${r?`${r.high} / ${r.medium} / ${r.low}`:'—'}</td><td>${r?(r.platforms||[]).map(p=>PL[p]||p).join(', ')||'—':'—'}</td><td class="n">${r?`${r.actionsDone} of ${r.actionsTotal}`:'—'}</td>
        <td style="white-space:nowrap"><button class="btn quiet small" data-act="user" data-u="${esc(u.username)}" data-a="${u.isAdmin?'remove_admin':'make_admin'}">${u.isAdmin?'Remove admin':'Make admin'}</button>${self?'':`<button class="btn quiet small" style="color:var(--high)" data-act="user" data-u="${esc(u.username)}" data-a="delete">Delete</button>`}</td></tr>`;}).join('')}
    </tbody></table></div></div></div>`;};
