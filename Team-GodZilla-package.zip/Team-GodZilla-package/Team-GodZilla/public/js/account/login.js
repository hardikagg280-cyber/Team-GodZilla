/* Sign-in and sign-up page */
R.login=()=>{const el=$('[data-view="login"]');const reg=ACC.mode==='register';
  const form=reg?`<form data-form="register">
      <label class="field"><span>Username</span><input name="username" autocomplete="username" minlength="3" maxlength="40" pattern="[A-Za-z0-9_.\\-]+" title="Letters, numbers, dots, dashes or underscores" required></label>
      <label class="field"><span>Password</span><input name="password" type="password" autocomplete="new-password" minlength="6" required></label>
      <label class="field"><span>Confirm password</span><input name="confirm" type="password" autocomplete="new-password" minlength="6" required></label>
      <button class="btn primary full" ${ACC.busy?'disabled':''}>${ACC.busy?'Creating account…':'Create account'}</button></form>
      <p class="small" style="margin:14px 0 0">Already have an account? <button class="btn quiet" data-act="mode" data-m="login">Sign in</button></p>`
    :`<form data-form="login">
      <label class="field"><span>Username</span><input name="username" autocomplete="username" required></label>
      <label class="field"><span>Password</span><input name="password" type="password" autocomplete="current-password" required></label>
      <button class="btn primary full" ${ACC.busy?'disabled':''}>${ACC.busy?'Signing in…':'Sign in'}</button></form>
      <p class="small" style="margin:14px 0 0">New here? <button class="btn quiet" data-act="mode" data-m="register">Create an account</button></p>`;
  el.innerHTML=`<div class="login-wrap"><div class="panel login-card">
    <div class="brand" style="padding:0;margin-bottom:26px">${$('.brand svg').outerHTML}PrivacyLens</div>
    <h1 style="font-size:32px">${reg?'Create your account.':'Sign in to start your privacy audit.'}</h1>
    <p class="muted" style="margin:12px 0 22px">${reg?'Anyone can create an account. The first account on this site becomes the admin.':'Your archives are analyzed in your browser and never uploaded. Signing in saves only a summary of your results.'}</p>
    ${ACC.err?`<div class="alert err" style="margin-bottom:14px">${esc(ACC.err)}</div>`:''}
    ${!ACC.ready?'<p class="muted">Connecting…</p>':ACC.apiOk?form:'<div class="alert warn">Accounts work when the site runs on Netlify or with <b>npm run dev</b>. You can still use every feature as a guest.</div>'}
    <div class="or">or</div>
    <button class="btn full" data-act="guest">Continue as guest</button>
    <p class="small muted" style="margin:14px 0 0">Guests can use every feature, but nothing is saved.</p></div></div>`;
  const first=el.querySelector('input');if(first)first.focus();};
async function doAuth(kind,form){const fd=new FormData(form);const username=String(fd.get('username')||'').trim(),password=String(fd.get('password')||'');
  if(kind==='register'&&password!==fd.get('confirm')){ACC.err='The two passwords don’t match.';R.login();return;}
  ACC.err='';ACC.busy=true;R.login();
  try{const d=await api('/'+kind,{method:'POST',body:{username,password}});saveToken(d.token);ACC.user=d.user;setSession('account');ACC.busy=false;
    if(kind==='register'&&d.user.isAdmin)toast('Account created. As the first account, you’re the admin.');else toast('Signed in as '+d.user.username);
    const t=ACC.intended;ACC.intended=null;go(t&&t!=='login'?t:'dashboard');}
  catch(e){ACC.busy=false;ACC.err=e.message;R.login();}}
