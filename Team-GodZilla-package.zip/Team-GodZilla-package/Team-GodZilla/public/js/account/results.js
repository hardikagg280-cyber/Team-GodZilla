/* Saving result summaries and progress to the signed-in account */
function canSave(){return ACC.session==='account'&&ACC.user&&ACC.apiOk;}
function summaryDoc(){const c={High:0,Medium:0,Low:0};S.findings.forEach(f=>c[f.level]++);
  return{score:S.score,rating:scoreLabel(S.score),platforms:uniq(S.archives.map(a=>a.platform)),high:c.High,medium:c.Medium,low:c.Low,actionsDone:S.actions.filter(a=>done.has(a.id)).length,actionsTotal:S.actions.length,demo:!!S.demo};}
async function recordAnalysis(){if(!canSave()||!hasData())return;try{await api('/results',{method:'POST',body:summaryDoc()});ACC.saved=true;}catch(e){}}
let syncT;
function syncActions(){if(!canSave()||!ACC.saved)return;clearTimeout(syncT);syncT=setTimeout(()=>{api('/results/progress',{method:'POST',body:{actionsDone:S.actions.filter(a=>done.has(a.id)).length,actionsTotal:S.actions.length}}).catch(()=>{});},1200);}
function renderNotice(){const n=$('#notice');if(!n)return;n.hidden=!ACC.notice||!ACC.session;n.textContent=ACC.notice||'';}
