/* Accounts: API client, session and the signed-in user panel */
const ACC={ready:false,apiOk:null,session:null,user:null,token:null,records:null,recErr:null,notice:'',intended:null,mode:'login',err:'',busy:false};
try{ACC.token=localStorage.getItem('footprints.token');ACC.session=sessionStorage.getItem('privacylens.session');}catch(e){}
function setSession(v){ACC.session=v;try{if(v)sessionStorage.setItem('privacylens.session',v);else sessionStorage.removeItem('privacylens.session');}catch(e){}}
function saveToken(t){ACC.token=t;try{if(t)localStorage.setItem('footprints.token',t);else localStorage.removeItem('footprints.token');}catch(e){}}
const initials=n=>(n||'?').trim().split(/[\s._-]+/).map(x=>x[0]).slice(0,2).join('').toUpperCase()||'?';
const avatar=(name,color,size)=>`<span class="avatar" style="background:${color||'var(--accent)'};width:${size||36}px;height:${size||36}px" aria-hidden="true">${esc(initials(name))}</span>`;
async function api(path,opts){opts=opts||{};const h={'Content-Type':'application/json'};if(ACC.token)h.Authorization='Bearer '+ACC.token;
  const r=await fetch('/api'+path,{method:opts.method||'GET',headers:h,body:opts.body?JSON.stringify(opts.body):undefined});
  let d=null;try{d=await r.json();}catch(e){}
  if(!r.ok||!d){const e=new Error((d&&d.error)||'The server didn’t respond. Try again.');e.status=r.status;throw e;}
  return d;}
async function initAccount(){
  try{const d=await api('/notice');ACC.apiOk=true;ACC.notice=d.notice||'';}catch(e){ACC.apiOk=false;}
  if(ACC.apiOk&&ACC.token){try{const d=await api('/me');ACC.user=d.user;if(ACC.session!=='guest')setSession('account');}catch(e){saveToken(null);ACC.user=null;if(ACC.session==='account')setSession(null);}}
  else if(ACC.session==='account')setSession(null);
  ACC.ready=true;show();}
function renderShell(){
  const nav=$('#nav-admin');if(nav)nav.hidden=!(ACC.user&&ACC.user.isAdmin&&ACC.session==='account');
  const w=$('#who');if(!w)return;
  if(ACC.session==='account'&&ACC.user)w.innerHTML=`${avatar(ACC.user.username,null,32)}<span class="who-t"><b>${esc(ACC.user.username)}</b><small>${ACC.user.isAdmin?'Admin':'Member'}</small></span><button class="btn quiet small" data-act="logout">Sign out</button>`;
  else if(ACC.session)w.innerHTML=`${avatar('G','var(--muted)',32)}<span class="who-t"><b>Guest</b><small>Results not saved</small></span><button class="btn quiet small" data-act="logout">Sign in</button>`;
  else w.innerHTML='';
  renderNotice();}
