/* App start-up and event handling */
document.addEventListener('click',e=>{const b=e.target.closest('[data-act]');if(!b)return;const a=b.dataset.act;
  if(a==='go')go(b.dataset.v);
  else if(a==='demo')runDemo();
  else if(a==='browse')$('#file').click();
  else if(a==='platform'){UI.platform=b.dataset.p;R.upload();}
  else if(a==='guide'){UI.scrollTo=b.dataset.g;go('guide');}
  else if(a==='cat'){UI.explCat=b.dataset.c;R.footprint();}
  else if(a==='epf'){UI.explPf=b.dataset.p;R.footprint();}
  else if(a==='riskf'){UI.riskF=b.dataset.l;R.risks();}
  else if(a==='actf'){UI.actF=b.dataset.f;R.actions();}
  else if(a==='pdf')makePdf();
  else if(a==='json')exportJson();
  else if(a==='mode'){ACC.mode=b.dataset.m;ACC.err='';R.login();}
  else if(a==='admin-refresh')loadAdmin();
  else if(a==='user')manageUser(b.dataset.u,b.dataset.a);
  else if(a==='guest'){setSession('guest');const t=ACC.intended;ACC.intended=null;go(t&&t!=='login'&&t!=='admin'?t:'dashboard');}
  else if(a==='logout'){if(ACC.session==='account'){saveToken(null);ACC.user=null;}setSession(null);ACC.mode='login';const ad=$('[data-view="admin"]');if(ad)ad.dataset.mode='';go('login');}
  else if(a==='save-notice'||a==='clear-notice')saveNotice(a==='clear-notice');
  else if(a==='reset'){fresh();UI.msg=null;UI.explPf='all';toast('Analysis cleared');go('upload');}
});
document.addEventListener('change',e=>{const t=e.target;
  if(t.id==='file'){handleFiles([...t.files]);t.value='';}
  else if(t.dataset&&t.dataset.done){const id=t.dataset.done;if(t.checked)done.add(id);else done.delete(id);saveDone();syncActions();
    const card=t.closest('.action');if(card)card.classList.toggle('done',t.checked);setTimeout(()=>R.actions(),t.checked?450:0);}
});
document.addEventListener('dragover',e=>e.preventDefault());
document.addEventListener('drop',e=>{if(!e.target.closest('#drop')){e.preventDefault();if(e.dataTransfer&&e.dataTransfer.files.length){go('upload');handleFiles([...e.dataTransfer.files]);}}});
document.addEventListener('submit',e=>{const f=e.target.closest('form[data-form]');if(!f)return;e.preventDefault();doAuth(f.dataset.form,f);});
addEventListener('hashchange',show);
loadDemo();
show();
initAccount();
