/* Synthetic demo archives (fictional person). Same file layouts as real exports. */
function makeDemoArchives(){
  let s=20251122;
  const rnd=()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
  const pick=a=>a[Math.floor(rnd()*a.length)];
  const START=Date.UTC(2025,0,1), DAYS=300, H=3600e3, IST=5.5*H;
  const at=(d,h)=>START+d*24*H+h*H-IST;
  const iso=ms=>new Date(ms).toISOString();
  const sec=ms=>Math.floor(ms/1000);
  const J=o=>JSON.stringify(o,null,1);
  const places=[
    {name:'Lakeview Residency, Indiranagar',lat:12.9719,lng:77.6412},
    {name:'Koramangala Tech Park',lat:12.9352,lng:77.6245},
    {name:'Ironworks Fitness Studio',lat:12.9784,lng:77.6408},
    {name:'Brew Lab Café, Whitefield',lat:12.9698,lng:77.7499},
    {name:'Family home, Mysuru',lat:12.2958,lng:76.6394},
    {name:'Sakra Skin Clinic',lat:12.9310,lng:77.6850}];
  const jit=()=>(rnd()-0.5)*0.0016, E7=v=>Math.round(v*1e7);
  const recs=[], visits=[];
  const rec=(p,ms)=>recs.push({latitudeE7:E7(p.lat+jit()),longitudeE7:E7(p.lng+jit()),accuracy:10+Math.floor(rnd()*40),timestamp:iso(ms)});
  for(let d=0;d<DAYS;d++){
    const dow=new Date(START+d*864e5).getUTCDay(), wk=dow>0&&dow<6;
    if(d%34>=30){rec(places[4],at(d,10+rnd()*8));rec(places[4],at(d,23));if(d%34===30)visits.push([4,at(d,12)]);continue;}
    rec(places[0],at(d,23+rnd()));rec(places[0],at(d,7+rnd()));if(d%14===3)visits.push([0,at(d,20)]);
    if(wk){rec(places[1],at(d,10+rnd()*2));rec(places[1],at(d,15+rnd()*2));if(rnd()<0.15)visits.push([1,at(d,10)]);}
    if(wk&&dow%2===1){rec(places[2],at(d,19+rnd()));if(rnd()<0.3)visits.push([2,at(d,19)]);}
    if(!wk){rec(places[3],at(d,11+rnd()*3));visits.push([3,at(d,11)]);}
    if(d%45===12){rec(places[5],at(d,17));visits.push([5,at(d,17)]);}
  }
  const semantic={timelineObjects:visits.map(([i,ms])=>({placeVisit:{location:{latitudeE7:E7(places[i].lat),longitudeE7:E7(places[i].lng),name:places[i].name,address:places[i].name+', Karnataka, India'},duration:{startTimestamp:iso(ms),endTimestamp:iso(ms+1.5*H)}}}))};
  const queries=['best biryani near me','python pandas groupby example','cheap flights to goa','flats for rent koramangala 2bhk','dermatologist near indiranagar','symptoms of anxiety at night','personal loan interest rates','how to negotiate salary','visa appointment chennai consulate','therapist in bengaluru','credit card debt help','product designer jobs bengaluru','weather bengaluru','ipl schedule','how to make cold brew','resignation letter format','bus to mysuru timings','gym membership indiranagar price','home loan eligibility calculator','blood test fasting rules'];
  const hrs=[9,11,13,14,18,20,21,22,23,0.5,1];
  const search=[];for(let k=0;k<180;k++){const q=pick(queries);search.push({header:'Search',title:'Searched for '+q,titleUrl:'https://www.google.com/search?q='+encodeURIComponent(q),time:iso(at(Math.floor(rnd()*DAYS),pick(hrs)+rnd())),products:['Search']});}
  search.sort((a,b)=>b.time.localeCompare(a.time));
  const vids=[['Morning yoga for beginners','Yoga Daily'],['Personal finance in your 20s','Money Basics'],['Bengaluru street food tour','Food Trails'],['Figma auto layout tutorial','Design Lab'],['How to deal with anxiety','Mind Matters'],['IPL highlights','Cricket Now'],['Lo-fi beats to study to','Chill Room'],['Home workout no equipment','FitHome'],['Resume tips for designers','Career Studio'],['Goa travel vlog','Wander Diaries']];
  const watch=[];for(let k=0;k<150;k++){const v=pick(vids);watch.push({header:'YouTube',title:'Watched '+v[0],titleUrl:'https://www.youtube.com/watch?v=demo'+k,subtitles:[{name:v[1]}],time:iso(at(Math.floor(rnd()*DAYS),pick([7,13,20,21,22,23,0.5])+rnd())),products:['YouTube']});}
  const first=['Aarav','Ananya','Rohan','Priya','Kabir','Meera','Vikram','Isha','Arjun','Neha','Karthik','Divya','Siddharth','Pooja','Rahul','Sneha','Aditya','Kavya','Nikhil','Riya'];
  const last=['Rao','Sharma','Iyer','Menon','Reddy','Nair','Gupta','Shetty','Das','Kulkarni'];
  let vcf='';for(let k=0;k<45;k++)vcf+=`BEGIN:VCARD\nVERSION:3.0\nFN:${pick(first)} ${pick(last)}\nTEL;TYPE=CELL:+91 90000 ${10000+k*37}\nEND:VCARD\n`;
  const profile={displayName:'Demo User',name:{givenName:'Demo',familyName:'User'},emails:[{value:'demo.user@example.com',type:'account'}],birthday:'1999-04-12'};
  const G='Takeout/';
  const google=[
    {path:G+'Location History (Timeline)/Records.json',text:J({locations:recs})},
    {path:G+'Location History (Timeline)/Semantic Location History/2025/2025_ALL.json',text:J(semantic)},
    {path:G+'My Activity/Search/MyActivity.json',text:J(search)},
    {path:G+'YouTube and YouTube Music/history/watch-history.json',text:J(watch)},
    {path:G+'Contacts/All Contacts/All Contacts.vcf',text:vcf},
    {path:G+'Profile/Profile.json',text:J(profile)},
    {path:G+'archive_browser.html',text:'<html><body>Archive overview</body></html>'}];
  // Instagram
  const adj=['sunny','urban','quiet','wild','chai','pixel','lazy','neon','tiny','retro'],noun=['traveller','lens','foodie','runner','doodles','beats','reads','kitchen','studio','diaries'];
  const user=()=>`${pick(adj)}_${pick(noun)}${Math.floor(rnd()*900+100)}`;
  const tsec=()=>sec(at(Math.floor(rnd()*DAYS),pick([8,12,19,21,22,23,0.5])+rnd()));
  const sld=u=>({title:'',media_list_data:[],string_list_data:[{href:'https://www.instagram.com/'+u,value:u,timestamp:tsec()}]});
  const followers=[];for(let k=0;k<140;k++)followers.push(sld(user()));
  const following=[];for(let k=0;k<190;k++)following.push(sld(user()));
  const topics=['Street food','Fitness','Personal finance','Indie music','Travel in India','Startups','Mental wellness','Sneakers','Photography','Cricket','Coffee','Home decor','Dating','Skincare','Running','Tech gadgets','Pets','Yoga','Stand-up comedy','Cooking'];
  const igs=[];for(let k=0;k<35;k++)igs.push({title:'',string_map_data:{Search:{href:'',value:user(),timestamp:0},Time:{href:'',value:'',timestamp:tsec()}}});
  const likes=[];for(let k=0;k<220;k++)likes.push({title:user(),string_list_data:[{href:'https://www.instagram.com/p/demo'+k,value:'👍',timestamp:tsec()}]});
  const ips=['49.37.164.','106.51.72.','223.186.20.'];
  const logins=[];for(let k=0;k<25;k++){const t=tsec();logins.push({title:new Date(t*1000).toISOString(),string_map_data:{'IP Address':{value:pick(ips)+Math.floor(rnd()*250)},Time:{timestamp:t},'User Agent':{value:'Instagram 312.0 Android'}}});}
  const msgs=[];for(let k=0;k<60;k++)msgs.push({sender_name:rnd()<0.5?'Ananya Rao':'Demo User',timestamp_ms:tsec()*1000,content:'(message)'});
  msgs.sort((a,b)=>b.timestamp_ms-a.timestamp_ms);
  const I='instagram-demo.lens-2025-11-01/';
  const instagram=[
    {path:I+'connections/followers_and_following/followers_1.json',text:J(followers)},
    {path:I+'connections/followers_and_following/following.json',text:J({relationships_following:following})},
    {path:I+'preferences/your_topics/your_topics.json',text:J({topics_your_topics:topics.map(t=>({string_map_data:{Name:{href:'',value:t,timestamp:0}}}))})},
    {path:I+'personal_information/information_about_you/locations_of_interest.json',text:J({label_values:[{label:'Locations of interest',vec:[{value:'Bengaluru, Karnataka'},{value:'Indiranagar, Bengaluru'},{value:'Mysuru, Karnataka'},{value:'Goa'}]}]})},
    {path:I+'logged_information/recent_searches/account_searches.json',text:J({searches_user:igs})},
    {path:I+'your_instagram_activity/likes/liked_posts.json',text:J({likes_media_likes:likes})},
    {path:I+'personal_information/personal_information/personal_information.json',text:J({profile_user:[{media_map_data:{},string_map_data:{Email:{value:'demo.user@example.com'},'Phone Number':{value:'+91 98450 12345'},Username:{value:'demo.lens'},Name:{value:'Demo User'},'Date of birth':{value:'1999-04-12'},Gender:{value:'Male'}}}]})},
    {path:I+'security_and_login_information/login_and_profile_creation/login_activity.json',text:J({account_history_login_history:logins})},
    {path:I+'your_instagram_activity/messages/inbox/ananyarao_1234/message_1.json',text:J({participants:[{name:'Ananya Rao'},{name:'Demo User'}],messages:msgs})}];
  // Spotify
  const artists=['Prateek Kuhad','Arijit Singh','Anuv Jain','Ritviz','The Local Train','Lifafa','Taylor Swift','Coldplay','The Weeknd','A.R. Rahman','When Chai Met Toast','Dua Lipa','Hanumankind','Seedhe Maut','Norah Jones','Peter Cat Recording Co.','Bloodywood','Lofi Girl'];
  const titles=['Track 1','Track 2','Track 3','Track 4','Track 5','Track 6'];
  const pad=n=>String(n).padStart(2,'0');
  const stream=[];for(let k=0;k<700;k++){const a=artists[Math.min(artists.length-1,Math.floor(Math.pow(rnd(),1.8)*artists.length))];const d=new Date(at(Math.floor(rnd()*DAYS),pick([8,9,10,13,18,19,22,23,0.5,1])+rnd()));stream.push({endTime:`${d.getUTCFullYear()}-${pad(d.getUTCMonth()+1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`,artistName:a,trackName:pick(titles),msPlayed:60000+Math.floor(rnd()*180000)});}
  stream.sort((a,b)=>a.endTime.localeCompare(b.endTime));
  const sq=[];for(let k=0;k<40;k++)sq.push({platform:'ANDROID',searchTime:iso(at(Math.floor(rnd()*DAYS),pick([9,19,22,23])+rnd())),searchQuery:pick(['lofi','sad songs','workout mix','prateek kuhad','sleep sounds','focus music','road trip','arijit','breakup songs','meditation'])});
  const inf=['1P_Custom_Fitness_Enthusiasts','3P_Travel_Lovers','1P_Podcast_Listeners','3P_Car_Intenders','1P_Young_Professionals','3P_Personal_Finance','1P_Late_Night_Listeners','3P_Food_Delivery_Users','3P_Mobile_Gamers','1P_Indie_Music_Fans','3P_Credit_Card_Applicants','3P_Online_Shoppers','1P_Commuters','3P_Health_and_Wellness','3P_Real_Estate_Interested','1P_Bollywood_Fans'];
  const S='Spotify Account Data/';
  const spotify=[
    {path:S+'StreamingHistory_music_0.json',text:J(stream)},
    {path:S+'SearchQueries.json',text:J(sq)},
    {path:S+'Inferences.json',text:J({inferences:inf})},
    {path:S+'Userdata.json',text:J({username:'31demolens',email:'demo.user@example.com',country:'IN',createdFromFacebook:false,birthdate:'1999-04-12',gender:'male',postalCode:'560038',mobileNumber:'+91 98450 12345',mobileOperator:'Jio',mobileBrand:'Samsung',creationTime:'2019-06-02'})},
    {path:S+'Follow.json',text:J({userIsFollowing:artists.slice(0,8).concat(['ananya.rao','kabir.m','priya_iyer']),userIsFollowedBy:['ananya.rao','kabir.m','priya_iyer','rohan.d','meera.n','isha_k','arjun.s'],userIsBlocking:[]})}];
  return {google:{name:'google-takeout-demo.zip',files:google},instagram:{name:'instagram-demo.zip',files:instagram},spotify:{name:'spotify-demo.zip',files:spotify}};
}
