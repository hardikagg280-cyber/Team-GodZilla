/* Report downloads: PDF (jsPDF) and JSON summary */
let dlP=null;
function getDownloads(){if(!window.claude||typeof window.claude.use!=='function')return Promise.resolve(null);return dlP||(dlP=window.claude.use('downloads').catch(()=>null));}
async function saveFile(name,data){const dl=await getDownloads();
  if(!dl){try{const blob=data instanceof Blob?data:new Blob([data],{type:name.endsWith('.pdf')?'application/pdf':'application/json'});const u=URL.createObjectURL(blob);const a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),4000);toast('Saved '+name);}catch(e){toast('The file couldn’t be saved.');}return;}
  try{await dl.save({filename:name,data});toast('Saved '+name);}catch(e){toast(e&&e.code==='declined'?'Download cancelled.':'The file couldn’t be saved here.');}}
function pdfSafe(s){return String(s).replace(/[“”]/g,'"').replace(/[‘’]/g,"'").replace(/[–—]/g,'-').replace(/…/g,'...').replace(/·/g,'-').replace(/[^\x09\x0A\x0D\x20-\x7E\xA0-\xFF]/g,'');}
async function makePdf(){if(!window.jspdf){toast('The PDF tool didn’t load. Reload the page and try again.');return;}
  const doc=new window.jspdf.jsPDF({unit:'pt',format:'a4'});const M=56,W=doc.internal.pageSize.getWidth()-2*M,PH=doc.internal.pageSize.getHeight();let y=64;
  const txt=(t,o)=>{o=o||{};const size=o.size||11;doc.setFont('helvetica',o.bold?'bold':'normal');doc.setFontSize(size);doc.setTextColor.apply(doc,o.color||[23,38,43]);
    for(const line of doc.splitTextToSize(pdfSafe(t),W-(o.indent||0))){if(y>PH-56){doc.addPage();y=64;}doc.text(line,M+(o.indent||0),y);y+=size*1.4;}y+=o.after!=null?o.after:4;};
  const pfs=uniq(S.archives.map(a=>a.platform));
  txt('PrivacyLens report',{size:22,bold:true,after:2});
  txt(new Date().toLocaleDateString(undefined,{dateStyle:'long'})+(S.demo?' - demo data':''),{size:10,color:[86,103,108],after:14});
  txt(`Privacy score: ${S.score}/100 (${scoreLabel(S.score)})`,{size:15,bold:true});
  txt(`Platforms analyzed: ${pfNames(pfs)}. Data categories identified: ${S.findings.length}. High-risk findings: ${S.findings.filter(f=>f.level==='High').length}.`,{after:14});
  txt('Digital footprint summary',{size:14,bold:true});summaryLines().forEach(l=>txt('- '+l,{indent:6}));y+=8;
  for(const l of ['High','Medium','Low']){const g=S.findings.filter(f=>f.level===l);if(!g.length)continue;txt(`${l}-risk findings`,{size:14,bold:true,color:l==='High'?[185,54,38]:l==='Medium'?[153,101,10]:[37,122,77]});
    g.forEach(f=>{txt(f.title,{bold:true,after:0});txt(f.detected,{after:0});txt('Why it matters: '+f.why,{after:0});txt('Possible impact: '+f.impact,{after:8});});}
  txt('Recommended actions',{size:14,bold:true});
  S.actions.forEach(a=>{txt(`[${done.has(a.id)?'x':' '}] ${a.title} (${a.priority} priority)`,{bold:true,after:0});a.steps.forEach((s,i)=>txt(`${i+1}. ${s}`,{indent:14,size:10,after:0}));y+=6;});
  y+=6;txt(`Completed: ${S.actions.filter(a=>done.has(a.id)).length} of ${S.actions.length}. Generated on this device by PrivacyLens; no data was uploaded.`,{size:9,color:[86,103,108]});
  await saveFile('privacylens-report.pdf',doc.output('arraybuffer'));}
function exportJson(){const pfs=uniq(S.archives.map(a=>a.platform));
  const o={generated:new Date().toISOString(),demo:S.demo,score:S.score,rating:scoreLabel(S.score),platforms:pfs.map(p=>PL[p]),archives:S.archives.map(a=>({name:a.name,platform:PL[a.platform],filesRead:a.parsed,records:a.records})),
    findings:S.findings.map(f=>({concern:f.title,risk:f.level,detected:f.detected,whyItMatters:f.why,impact:f.impact,platforms:f.platforms.map(p=>PL[p])})),
    actions:S.actions.map(a=>({action:a.title,priority:a.priority,platform:a.pf==='any'?'All':PL[a.pf],status:done.has(a.id)?'done':'pending'}))};
  saveFile('privacylens-summary.json',JSON.stringify(o,null,2));}
