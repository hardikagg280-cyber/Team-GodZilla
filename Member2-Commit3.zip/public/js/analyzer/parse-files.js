/* Reads each file in an archive (JSON, VCF, CSV, HTML) and sends it to the right parser */
function parseFile(pf,path,text){
  const lower=path.toLowerCase(),before=total(),ext=lower.split('.').pop();
  if(ext==='vcf')parseVcf(pf,text);
  else if(ext==='json'){let d;try{d=JSON.parse(text);}catch(e){return false;}if(d&&typeof d==='object')parseJson(pf,lower,d);}
  else if(ext==='html'||ext==='htm')parseHtml(pf,lower,text);
  else if(ext==='csv')parseCsv(pf,lower,text);
  return total()>before;
}
function parseVcf(pf,text){for(const card of text.split(/BEGIN:VCARD/i).slice(1)){const m=card.match(/^FN[^:]*:(.+)$/im);addContact(pf,m?m[1].trim():'Unnamed contact','address book');}}
function parseCsv(pf,lower,text){if(!/contact/.test(lower))return;const rows=text.split(/\r?\n/).filter(Boolean);if(rows.length<2)return;
  const head=rows[0].split(',').map(h=>h.replace(/"/g,'').trim().toLowerCase());let i=head.findIndex(h=>h==='name'||h==='first name'||h==='display name');if(i<0)i=0;
  for(const r of rows.slice(1,20001)){const c=r.split(',')[i];addContact(pf,(c||'').replace(/"/g,'').trim(),'address book');}}
function parseHtml(pf,lower,text){
  if(!/activity|history/.test(lower)||typeof DOMParser==='undefined')return;
  const doc=new DOMParser().parseFromString(text,'text/html');const strip=s=>s.replace(/<[^>]+>/g,'').replace(/&amp;/g,'&').replace(/&nbsp;|\u202f/g,' ').trim();
  let n=0;for(const c of doc.querySelectorAll('.outer-cell')){if(n++>40000)break;const cc=c.querySelector('.content-cell');if(!cc)continue;
    const lines=cc.innerHTML.split(/<br\s*\/?>/i).map(strip).filter(Boolean);if(!lines.length)continue;
    let t=null;for(const l of lines){const m=l.match(/([A-Z][a-z]{2,8}\.? \d{1,2}, \d{4},? \d{1,2}:\d{2}(:\d{2})?\s?[AP]M)/)||l.match(/(\d{1,2} [A-Z][a-z]{2,8}\.? \d{4},? \d{1,2}:\d{2}(:\d{2})?)/);if(m){t=Date.parse(m[1].replace(',',''))||Date.parse(m[1]);break;}}
    googleAct(pf,lower,lines[0],t||null,'');}}
function googleAct(pf,lower,title,time,who){title=String(title||'');let type='activity',text=title;
  if(/^Searched for /.test(title)){type='search';text=title.slice(13);}
  else if(/^Watched /.test(title)){type='watch';text=title.slice(8);}
  else if(/^Visited /.test(title)){type='browse';text=title.slice(8);}
  else if(/^Listened to /.test(title)){type='listen';text=title.slice(12);}
  else if(/search/.test(lower))type='search';
  addAct(pf,type,text,time,who);}

function parseJson(pf,lower,d){
  if(parseGoogleJson(pf,lower,d))return;
  if(parseSpotifyJson(pf,lower,d))return;
  if(parseInstagramJson(pf,lower,d))return;
  genericScan(pf,lower,d);
}
function genericScan(pf,lower,d){let c=0;
  const type=/post|media|photo/.test(lower)?'post':/comment/.test(lower)?'comment':/like/.test(lower)?'like':'activity';
  walk(d,o=>{if(Array.isArray(o)||c>5000)return;const lat=o.latitude!=null?o.latitude:o.lat,lng=o.longitude!=null?o.longitude:(o.lng!=null?o.lng:o.lon);
    if(typeof lat==='number'&&typeof lng==='number'){addLoc(pf,lat,lng,o.timestamp||o.creation_timestamp||o.time,o.name||'','generic');c++;return;}
    const t=o.creation_timestamp!=null?o.creation_timestamp:(o.timestamp_ms!=null?o.timestamp_ms:o.timestamp);
    if(t!=null&&validT(toMs(t))){addAct(pf,type,decodeIG(o.title||o.name||''),t);c++;}});}
