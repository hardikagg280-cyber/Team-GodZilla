/* Risk analyzer page */
const mask=(t,v)=>{v=String(v);if(t==='Email'){const[a,b]=v.split('@');return a[0]+'•••@'+(b||'');}if(t==='Phone number')return v.replace(/\d(?=(?:\D*\d){2})/g,'•');if(t==='IP address')return v.split('.').slice(0,2).join('.')+'.•.•';if(t==='Birth date')return '••••-••-•• ('+(v.match(/\d{4}/)||['?'])[0]+')';if(t==='Postal code')return v.slice(0,2)+'••••';return v;};
R.risks=()=>{const el=$('[data-view="risks"]');
  if(!hasData()){el.innerHTML=`<h1>What could this data reveal?</h1><p class="lede">Risks appear here after you analyze an archive.</p>${emptyState('No risks to show yet','Upload an archive or load the demo data.')}`;return;}
  const c={High:0,Medium:0,Low:0};S.findings.forEach(f=>c[f.level]++);
  const list=S.findings.filter(f=>UI.riskF==='all'||f.level===UI.riskF);
  el.innerHTML=`<h1>What could this data reveal?</h1><p class="lede">Each finding is rated by how sensitive the data is, how much of it exists and what someone could infer from it.</p>
  <div class="levels">${['High','Medium','Low'].map(l=>`<div class="lv-${l}"><b>${c[l]}</b>${l} risk${c[l]===1?'':'s'}</div>`).join('')}</div>
  <div class="toolbar" style="margin-top:24px"><div class="seg" role="group" aria-label="Risk level">${['all','High','Medium','Low'].map(l=>`<button data-act="riskf" data-l="${l}" aria-pressed="${UI.riskF===l}">${l==='all'?'All risks':l}</button>`).join('')}</div></div>
  <div class="stack">${list.map(f=>`<article class="panel finding"><header><h2 style="margin:0">${esc(f.title)}</h2>${badge(f.level)}</header>
    <dl><dt>What was detected</dt><dd>${esc(f.detected)}</dd><dt>Why it matters</dt><dd>${esc(f.why)}</dd><dt>Possible impact</dt><dd>${esc(f.impact)}</dd><dt>Found in</dt><dd>${pfNames(f.platforms)}</dd>
    ${f.cat==='identifiers'?`<dt>Details</dt><dd><div class="chips">${S.identifiers.filter((x,i,a)=>x.type!=='IP address'||a.findIndex(y=>y.type==='IP address')===i).slice(0,14).map(x=>`<span class="chip">${esc(x.type)}: ${esc(mask(x.type,x.value))}</span>`).join('')}</div></dd>`:''}</dl>
    <div><button class="btn quiet" data-act="go" data-v="actions">See what to do</button></div></article>`).join('')||'<p class="muted">No findings at this level.</p>'}</div>`;};
