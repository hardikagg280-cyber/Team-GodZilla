/* Action plan page */
R.actions=()=>{const el=$('[data-view="actions"]');
  if(!hasData()){el.innerHTML=`<h1>What should you do first?</h1><p class="lede">Your personal action plan appears here after an analysis.</p>${emptyState('No action plan yet','Upload an archive or load the demo data to get prioritized steps.')}`;return;}
  const all=S.actions,nDone=all.filter(a=>done.has(a.id)).length;
  const list=all.filter(a=>UI.actF==='all'||(UI.actF==='done'?done.has(a.id):!done.has(a.id)));
  const pct=all.length?Math.round(nDone/all.length*100):0;
  el.innerHTML=`<h1>What should you do first?</h1><p class="lede">Your findings turned into steps, highest risk first. Each one says what to delete, restrict or lock down and links to the right setting.</p>
  <div class="panel"><div class="toolbar" style="margin-bottom:10px"><h2 style="margin:0">${nDone} of ${all.length} actions done</h2><span class="num">${pct}%</span></div><div class="progress"><i style="width:${pct}%"></i></div></div>
  <div class="toolbar" style="margin-top:22px"><div class="seg" role="group" aria-label="Show">${[['remaining','Remaining'],['done','Completed'],['all','All']].map(([k,n])=>`<button data-act="actf" data-f="${k}" aria-pressed="${UI.actF===k}">${n}</button>`).join('')}</div></div>
  ${['High','Medium','Low'].map(l=>{const g=list.filter(a=>a.priority===l);if(!g.length)return'';return `<div class="group-h">${badge(l)}<h2 style="margin:0">${l} priority</h2></div><div class="stack">${g.map(a=>`
    <article class="panel action ${done.has(a.id)?'done':''}"><input type="checkbox" data-done="${a.id}" ${done.has(a.id)?'checked':''} aria-label="Mark “${esc(a.title)}” as done"><div>
      <h3>${esc(a.title)}</h3><div class="meta" style="margin:4px 0 8px"><span>${a.pf==='any'?'All platforms':PL[a.pf]}</span><span>· ${esc(a.finding)}</span></div>
      <p style="margin:0">${esc(a.desc)}</p><ol>${a.steps.map(s=>`<li>${esc(s)}</li>`).join('')}</ol>
      ${a.links.length?`<div class="btnrow">${a.links.map(([t,u])=>`<a class="btn" href="${u}" target="_blank" rel="noopener noreferrer">${esc(t)}</a>`).join('')}</div>`:''}</div></article>`).join('')}</div>`;}).join('')}
  ${list.length?'':`<p class="muted" style="margin-top:20px">${UI.actF==='done'?'Nothing marked as done yet.':'All done. Run a new export in a few months to check again.'}</p>`}`;};
