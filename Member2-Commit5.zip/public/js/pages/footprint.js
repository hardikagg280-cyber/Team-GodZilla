/* Digital footprint explorer page */
R.footprint=()=>{const el=$('[data-view="footprint"]');
  if(!hasData()){el.innerHTML=`<h1>What do platforms know about you?</h1><p class="lede">After you upload an archive, this page shows the locations, interests, connections and activity found inside it.</p>${emptyState('Nothing to explore yet','Upload a ZIP export or load the demo data to see your footprint.')}`;return;}
  const pfs=uniq(S.archives.map(a=>a.platform));const cat=UI.explCat;
  const tabs=[['location','Location data'],['interests','Interests & preferences'],['contacts','Contacts & connections'],['activity','Activity patterns']];
  let body='';
  if(cat==='location'){const locs=filt(S.locations),pl=filt(S.places);const cl=clusters(locs);
    body=!locs.length&&!pl.length?`<p class="muted">No location data in ${UI.explPf==='all'?'these archives':PL[UI.explPf]+' data'}.</p>`:`
      <div class="kv"><div><b>${fmt(locs.length)}</b><span>location records</span></div><div><b>${cl.length}</b><span>distinct areas</span></div><div><b>${pl.length}</b><span>named places of interest</span></div><div><b>${span(locs)?monthYear(span(locs)[0]):'—'}</b><span>earliest record</span></div></div>
      ${locs.length?`<div class="panel figure" style="padding:14px">${locPlot(cl,locs)}</div>
      <div class="panel"><h2>Most-recorded places</h2><div class="tbl"><table><thead><tr><th>Place</th><th class="n">Records</th><th>First seen</th><th>Last seen</th></tr></thead><tbody>
      ${cl.slice(0,10).map(x=>`<tr><td>${esc(placeLabel(x))}${x.tag?` <span class="badge lv-High">${x.tag}</span>`:''}</td><td class="n">${fmt(x.n)}</td><td>${x.last?monthYear(x.first):'—'}</td><td>${x.last?monthYear(x.last):'—'}</td></tr>`).join('')}</tbody></table></div>
      <p class="muted small" style="margin:10px 0 0">“Likely home” is the place recorded most at night; “Likely work” the one recorded most on weekday office hours.</p></div>`:''}
      ${pl.length?`<div class="panel"><h2>Named places of interest</h2><div class="chips">${pl.map(p=>`<span class="chip">${esc(p.name)} <span class="muted small">${PL[p.platform]}</span></span>`).join('')}</div></div>`:''}`;}
  if(cat==='interests'){const it=filt(S.interests);const groups={};it.forEach(i=>{(groups[i.source]=groups[i.source]||new Set()).add(i.label);});
    const listens=filt(S.activities.filter(a=>a.type==='listen'));const ac={};listens.forEach(a=>{if(a.who)ac[a.who]=(ac[a.who]||0)+1;});const topA=Object.entries(ac).sort((a,b)=>b[1]-a[1]).slice(0,10);
    const watch=filt(S.activities.filter(a=>a.type==='watch'));const ch={};watch.forEach(a=>{if(a.who&&a.who!=='YouTube')ch[a.who]=(ch[a.who]||0)+1;});const topC=Object.entries(ch).sort((a,b)=>b[1]-a[1]).slice(0,8);
    body=!it.length&&!listens.length&&!watch.length?'<p class="muted">No interest data in this selection.</p>':`
      ${Object.entries(groups).map(([g,set])=>`<div class="panel"><h2>${esc(g)}</h2><p class="muted small">Labels the platform assigned to you, often used for ad targeting.</p><div class="chips">${[...set].map(l=>`<span class="chip">${esc(l)}</span>`).join('')}</div></div>`).join('')}
      <div class="cols">${topA.length?`<div class="panel"><h2>Top artists</h2><div class="tbl"><table><thead><tr><th>Artist</th><th class="n">Plays</th></tr></thead><tbody>${topA.map(([a,n])=>`<tr><td>${esc(a)}</td><td class="n">${fmt(n)}</td></tr>`).join('')}</tbody></table></div></div>`:''}
      ${topC.length?`<div class="panel"><h2>Most-watched channels</h2><div class="tbl"><table><thead><tr><th>Channel</th><th class="n">Videos</th></tr></thead><tbody>${topC.map(([a,n])=>`<tr><td>${esc(a)}</td><td class="n">${fmt(n)}</td></tr>`).join('')}</tbody></table></div></div>`:''}</div>`;}
  if(cat==='contacts'){const uc=uniqContacts(filt(S.contacts));const kinds={};uc.forEach(c=>(kinds[c.kind]=kinds[c.kind]||[]).push(c));
    body=!uc.length?'<p class="muted">No contacts or connections in this selection.</p>':`
      <div class="kv">${Object.entries(kinds).map(([k,a])=>`<div><b>${fmt(a.length)}</b><span>${esc(k)}</span></div>`).join('')}</div>
      ${Object.entries(kinds).map(([k,a])=>`<div class="panel"><h2 style="text-transform:none">${esc(k[0].toUpperCase()+k.slice(1))}</h2><ul class="namelist">${a.slice(0,90).map(c=>`<li title="${esc(c.name)}">${esc(c.name)} <span class="muted small">${PL[c.platform]}</span></li>`).join('')}</ul>${a.length>90?`<p class="muted small" style="margin:10px 0 0">Showing 90 of ${fmt(a.length)}.</p>`:''}</div>`).join('')}`;}
  if(cat==='activity'){const ev=timedEvents(UI.explPf);const acts=filt(S.activities);const types={};acts.forEach(a=>types[a.type]=(types[a.type]||0)+1);
    const se=acts.filter(a=>a.type==='search'&&a.t).sort((a,b)=>b.t-a.t).slice(0,15);
    body=!ev.length?'<p class="muted">No timestamped activity in this selection.</p>':`
      <div class="kv">${Object.entries(types).sort((a,b)=>b[1]-a[1]).map(([k,n])=>`<div><b>${fmt(n)}</b><span>${esc(k==='watch'?'videos watched':k==='listen'?'songs played':k==='search'?'searches':k==='like'?'likes':k==='message'?'messages':k==='login'?'logins':k==='browse'?'pages visited':k)}</span></div>`).join('')}</div>
      <div class="panel figure"><h2>Activity over time</h2>${monthBars(ev)}</div>
      <div class="panel figure"><h2>When you’re active</h2><p class="muted small">Darker squares mean more recorded activity at that day and hour (your local time).</p>${heat(ev)}</div>
      ${se.length?`<div class="panel"><h2>Recent searches</h2><div class="tbl"><table><thead><tr><th>Search</th><th>Platform</th><th>Date</th></tr></thead><tbody>${se.map(a=>`<tr><td>${esc(a.text)}</td><td>${PL[a.platform]}</td><td>${new Date(a.t).toLocaleDateString()}</td></tr>`).join('')}</tbody></table></div></div>`:''}`;}
  el.innerHTML=`<h1>What do platforms know about you?</h1><p class="lede">Everything below was found in the archives you provided${S.demo?' (demo data)':''}. Filter by platform or switch category.</p>
    <div class="toolbar"><div class="seg" role="group" aria-label="Category">${tabs.map(([k,n])=>`<button data-act="cat" data-c="${k}" aria-pressed="${cat===k}">${n}</button>`).join('')}</div>
    <div class="seg" role="group" aria-label="Platform"><button data-act="epf" data-p="all" aria-pressed="${UI.explPf==='all'}">All</button>${pfs.map(p=>`<button data-act="epf" data-p="${p}" aria-pressed="${UI.explPf===p}">${PL[p]}</button>`).join('')}</div></div>
    <div class="stack">${body}</div>`;};
