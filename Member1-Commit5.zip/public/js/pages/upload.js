/* Upload & analyze page: ZIP upload, platform detection, demo data */
const PINFO={auto:['Auto-detect','Any supported ZIP'],google:['Google','Takeout export'],instagram:['Instagram','Download your information'],spotify:['Spotify','Account data']};
const PHOW={auto:'Pick a platform to see where its download lives, or drop any supported ZIP. PrivacyLens recognizes the platform from the files inside.',
  google:'Go to takeout.google.com, choose Location History (Timeline), My Activity, YouTube, Contacts and Profile, set My Activity to JSON, then create a one-time .zip export.',
  instagram:'Open Accounts Center → Your information and permissions → Download your information. Choose “Download to device”, All time, and Format: JSON.',
  spotify:'Sign in at spotify.com, open Account → Privacy settings and request “Account data”. It arrives by email, usually within a few days.'};
R.upload=()=>{const el=$('[data-view="upload"]');const st=UI.status;
  el.innerHTML=`<h1>Start your privacy audit.</h1>
  <p class="lede">Choose a platform, download your data from it, then drop the ZIP here. The archive is opened in this browser tab and is never sent to a server.</p>
  <div class="steps">
    <div class="step on"><div class="step-n">1</div><div class="panel"><h2 style="margin:0">Select a platform</h2>
      <div class="pgrid">${Object.keys(PINFO).map(k=>`<button class="pcard" data-act="platform" data-p="${k}" aria-pressed="${UI.platform===k}"><b>${PINFO[k][0]}</b><span>${PINFO[k][1]}</span></button>`).join('')}</div></div></div>
    <div class="step on"><div class="step-n">2</div><div class="panel"><h2>Download your data</h2><p style="max-width:66ch">${esc(PHOW[UI.platform])}</p>
      <button class="btn quiet" data-act="guide" data-g="${UI.platform==='auto'?'g-google':'g-'+UI.platform}">Step-by-step instructions</button></div></div>
    <div class="step on"><div class="step-n">3</div><div class="stack" style="min-width:0">
      <div class="drop" id="drop"><h3>Drop your ZIP archive here</h3><p class="muted small">Supported: Google Takeout, Instagram (JSON format) and Spotify exports. You can add several.</p>
        <div class="btnrow" style="justify-content:center;margin-top:14px"><button class="btn primary" data-act="browse" ${UI.busy?'disabled':''}>Browse files</button><button class="btn" data-act="demo" ${UI.busy?'disabled':''}>Try the demo data</button></div></div>
      ${st?`<div class="panel"><div class="toolbar" style="margin-bottom:10px"><h3>${esc(st.title)}</h3><span class="num">${Math.round(st.p*100)}%</span></div><div class="progress"><i style="width:${st.p*100}%"></i></div><p class="muted small" style="margin:10px 0 0">${esc(st.text)}</p></div>`:''}
      ${(UI.msg||[]).map(m=>`<div class="alert ${m.kind}">${esc(m.text)}</div>`).join('')}
      ${S.archives.length?`<div class="panel"><h2>Analyzed archives</h2><div class="tbl"><table><thead><tr><th>Archive</th><th>Platform</th><th class="n">Files read</th><th class="n">Records found</th></tr></thead><tbody>
        ${S.archives.map(a=>`<tr><td>${esc(a.name)}</td><td>${PL[a.platform]}${a.detected?'':' <span class="muted small">(chosen)</span>'}</td><td class="n">${a.parsed} of ${a.supported}</td><td class="n">${fmt(a.records)}</td></tr>`).join('')}</tbody></table></div>
        <div class="btnrow" style="margin-top:16px"><button class="btn primary" data-act="go" data-v="footprint">Explore your footprint</button><button class="btn" data-act="go" data-v="dashboard">View dashboard</button><button class="btn quiet" data-act="reset">Clear all data</button></div></div>`:''}
    </div></div>
  </div>`;
  const d=$('#drop');
  d.addEventListener('dragover',e=>{e.preventDefault();d.classList.add('over');});
  d.addEventListener('dragleave',()=>d.classList.remove('over'));
  d.addEventListener('drop',e=>{e.preventDefault();d.classList.remove('over');handleFiles([...e.dataTransfer.files]);});
};
function setStatus(title,p,text){UI.status={title,p,text};const v=$('[data-view="upload"]');if(!v.hidden){const bar=v.querySelector('.progress i'),pt=v.querySelector('.panel .num'),tx=v.querySelector('.progress+p');if(bar&&tx){bar.style.width=(p*100)+'%';pt.textContent=Math.round(p*100)+'%';tx.textContent=text;}else R.upload();}}
async function handleFiles(files){if(UI.busy||!files.length)return;UI.busy=true;UI.msg=null;
  if(S.demo){fresh();}
  const notes=[];
  for(const f of files){
    try{
      if(!/\.zip$/i.test(f.name))throw new Error(`“${f.name}” isn’t a ZIP archive. Upload the .zip file you downloaded from the platform.`);
      if(typeof JSZip==='undefined')throw new Error('The ZIP reader didn’t load. Check your internet connection and reload the page.');
      UI.status={title:f.name,p:0,text:'Opening archive…'};R.upload();
      const zip=await JSZip.loadAsync(f);
      const entries=Object.values(zip.files).filter(e=>!e.dir&&!/(^|\/)(__MACOSX|\._)/.test(e.name));
      const det=detectPlatform(entries.map(e=>e.name));
      const pf=det||(UI.platform!=='auto'?UI.platform:'other');
      const sup=entries.filter(e=>/\.(json|vcf|html?|csv)$/i.test(e.name));
      const arc={name:f.name,platform:pf,detected:!!det,files:entries.length,supported:sup.length,parsed:0,records:0};
      const before=total();
      for(let i=0;i<sup.length;i++){const e=sup[i];const sz=e._data&&e._data.uncompressedSize;
        setStatus(f.name,i/sup.length,`Reading ${e.name.split('/').slice(-2).join('/')}`);
        if(sz>80*1024*1024)continue;
        try{const txt=await e.async('string');if(parseFile(pf,e.name,txt))arc.parsed++;}catch(err){}
        if(i%10===0)await new Promise(r=>setTimeout(r,0));}
      arc.records=total()-before;
      if(!arc.records){notes.push({kind:'warn',text:`${f.name}: no supported data found. ${pf==='instagram'?'Request the Instagram export in JSON format, not HTML.':'Check that this is an export from Google, Instagram or Spotify.'}`});}
      else{S.archives.push(arc);notes.push({kind:'ok',text:`${f.name}: ${PL[pf]} archive analyzed — ${fmt(arc.records)} records from ${arc.parsed} files.`});}
    }catch(err){notes.push({kind:'err',text:err.message&&/zip|corrupt|end of central/i.test(err.message)&&!/isn’t a ZIP|didn’t load/.test(err.message)?`${f.name} couldn’t be opened. The ZIP may be incomplete or damaged; try downloading it again.`:err.message});}
  }
  computeAll();UI.busy=false;UI.status=null;
  if(notes.some(n=>n.kind==='ok'))recordAnalysis();
  UI.msg=notes;
  R.upload();
}
function runDemo(){loadDemo();go('dashboard');toast('Demo data loaded');recordAnalysis();}
function loadDemo(){fresh();const A=makeDemoArchives();
  for(const k in A){const before=total();let parsed=0;for(const f of A[k].files)if(parseFile(k,f.path,f.text))parsed++;
    S.archives.push({name:A[k].name,platform:k,detected:true,files:A[k].files.length,supported:A[k].files.length,parsed,records:total()-before});}
  S.demo=true;computeAll();UI.msg=[{kind:'ok',text:'Demo data loaded: a fictional person’s Google, Instagram and Spotify exports. Upload your own ZIP to replace it.'}];}
