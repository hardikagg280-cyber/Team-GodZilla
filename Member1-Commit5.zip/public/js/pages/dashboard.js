/* Dashboard page */
R.dashboard=()=>{const el=$('[data-view="dashboard"]');
  if(!hasData()){el.innerHTML=`<h1>See what your apps know about you.</h1>
    <p class="lede">Upload the data exports you can download from Google, Instagram and Spotify. PrivacyLens reads them in your browser, shows what’s inside, rates the privacy risk and tells you what to fix first.</p>
    ${emptyState('No archives analyzed yet','Start with one ZIP file, such as a Google Takeout export. If you don’t have one yet, the demo data shows a full audit of a fictional person.')}`;return;}
  const pfs=uniq(S.archives.map(a=>a.platform));const remaining=S.actions.filter(a=>!done.has(a.id));
  const counts=CATS.map(c=>({c,n:catCount(c.id),f:S.findings.find(f=>f.cat===c.id)}));const maxN=Math.max(1,...counts.map(x=>x.n));
  const byP={High:0,Medium:0,Low:0};remaining.forEach(a=>byP[a.priority]++);
  el.innerHTML=`<h1>${S.score>=75?'Your footprint is fairly contained.':S.score>=50?'Some of your data needs attention.':'A lot of your personal data is exposed.'}</h1>
  <p class="lede">${S.demo?'Demo data for a fictional person. ':''}Based on ${S.archives.length} archive${S.archives.length===1?'':'s'} from ${pfNames(pfs)}. ${S.findings.filter(f=>f.level==='High').length} high risks and ${remaining.length} recommended actions remain.</p>
  <div class="stack">
  <div class="panel"><div class="overview">${dialSVG()}
    <div><h2 style="margin-bottom:4px">Privacy score: ${scoreLabel(S.score)}</h2><p class="muted small">Each segment of the ring is one data category, colored by its risk level. Higher scores mean less exposure.</p>
      <div class="dial-legend" style="margin-top:16px">${counts.map(x=>`<div><span class="dot" style="background:${x.f?LVC[x.f.level]:'var(--line)'}"></span>${esc(x.c.name)}${x.f?'':' <span class="muted">(none found)</span>'}</div>`).join('')}</div></div></div>
    <div class="stats">
      <div class="stat"><b>${pfs.length}</b><span>Platforms analyzed</span></div>
      <div class="stat"><b>${S.findings.length}</b><span>Data categories detected</span></div>
      <div class="stat"><b>${S.findings.filter(f=>f.level!=='Low').length}</b><span>High and medium risks</span></div>
      <div class="stat"><b>${remaining.length}</b><span>Actions to take</span></div></div></div>
  <div class="cols">
    <div class="panel"><h2 style="margin-bottom:2px">Category risk distribution</h2><p class="muted small">Relative risk by data category. Points further out mean riskier data.</p>${radarSVG()}</div>
    <div class="panel"><h2 style="margin-bottom:2px">Records by platform</h2><p class="muted small">Where your data trail comes from.</p>${platformBarsSVG()}</div>
  </div>
  <div class="cols">
    <div class="panel"><h2>Data exposure breakdown</h2>${counts.map(x=>`<div class="bar-row"><span>${esc(x.c.name)}</span><div class="track"><i style="width:${(x.n/maxN*100).toFixed(1)}%;background:${x.f?LVC[x.f.level]:'var(--line)'}"></i></div><span class="num">${fmt(x.n)}</span></div>`).join('')}
      <p class="muted small" style="margin:10px 0 0">Records found per category.</p></div>
    <div class="panel"><h2>High-priority concerns</h2>${S.findings.filter(f=>f.level!=='Low').slice(0,4).map(f=>`<div class="concern">${badge(f.level)}<h3>${esc(f.title)}</h3><p>${esc(f.detected)}</p></div>`).join('')||'<p class="muted">No high or medium risks found.</p>'}
      <button class="btn quiet" data-act="go" data-v="risks">See all risks</button></div>
  </div>
  <div class="panel"><div class="toolbar" style="margin-bottom:12px"><h2 style="margin:0">Recommended actions</h2><div class="chips">${['High','Medium','Low'].map(l=>`<span class="badge lv-${l}">${byP[l]} ${l.toLowerCase()}</span>`).join('')}</div></div>
    ${remaining.slice(0,3).map(a=>`<div class="concern">${badge(a.priority)}<h3>${esc(a.title)}</h3><p>${esc(a.desc)}</p></div>`).join('')||'<p class="muted">Every recommended action is done.</p>'}
    <div class="btnrow" style="margin-top:10px"><button class="btn primary" data-act="go" data-v="actions">Open action plan</button><button class="btn" data-act="go" data-v="footprint">Explore your footprint</button></div></div>
  </div>`;};
