/* Risk engine: places, activity patterns, findings and the privacy score */
const SENS={health:/symptom|doctor|clinic|therap|anxiety|depress|dermatolog|pregnan|blood test|medic|hospital|disease|pain|mental/i,
  money:/loan|debt|credit|salary|emi\b|bank|insurance|tax/i,work:/job|resign|interview|hiring|career|salary/i,
  relationships:/divorce|dating|breakup|wedding/i,'legal or immigration':/visa|lawyer|court|police|immigration/i};
const uniq=a=>[...new Set(a)];
const fmt=n=>Number(n).toLocaleString();
const monthYear=t=>new Date(t).toLocaleDateString(undefined,{month:'short',year:'numeric'});
function span(arr){let a=Infinity,b=0;for(const x of arr)if(x.t){if(x.t<a)a=x.t;if(x.t>b)b=x.t;}return b?[a,b]:null;}
function spanText(arr){const s=span(arr);if(!s)return'';const A=monthYear(s[0]),B=monthYear(s[1]);return A===B?` in ${A}`:` from ${A} to ${B}`;}
const hourLabel=h=>{const d=new Date(2000,0,1,h);return d.toLocaleTimeString(undefined,{hour:'numeric'});};
const DAYN=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

function clusters(locs){const grid=new Map(),list=[];const R=0.004;
  for(const l of locs){const gi=Math.floor(l.lat/0.01),gj=Math.floor(l.lng/0.01);let c=null;
    for(let a=-1;a<=1&&!c;a++)for(let b=-1;b<=1&&!c;b++){const cell=grid.get((gi+a)+':'+(gj+b));if(cell)for(const x of cell){if(Math.abs(x.sl-l.lat)<R&&Math.abs(x.sg-l.lng)<R){c=x;break;}}}
    if(!c){c={sl:l.lat,sg:l.lng,lat:0,lng:0,n:0,names:{},night:0,workday:0,first:Infinity,last:0,platforms:new Set(),tag:''};list.push(c);const key=gi+':'+gj;if(!grid.has(key))grid.set(key,[]);grid.get(key).push(c);}
    c.lat+=l.lat;c.lng+=l.lng;c.n++;if(l.name)c.names[l.name]=(c.names[l.name]||0)+1;c.platforms.add(l.platform);
    if(l.t){const d=new Date(l.t),h=d.getHours(),w=d.getDay();if(h>=22||h<6)c.night++;if(w>0&&w<6&&h>=9&&h<18)c.workday++;c.first=Math.min(c.first,l.t);c.last=Math.max(c.last,l.t);}}
  const m={values:()=>list};
  const arr=[...m.values()].map(c=>{c.lat/=c.n;c.lng/=c.n;const nm=Object.entries(c.names).sort((a,b)=>b[1]-a[1])[0];c.name=nm?nm[0]:'';return c;}).sort((a,b)=>b.n-a.n);
  const home=arr.slice().sort((a,b)=>b.night-a.night)[0];if(home&&home.night>=3)home.tag='Likely home';
  const work=arr.filter(c=>c!==home).sort((a,b)=>b.workday-a.workday)[0];if(work&&work.workday>=5)work.tag='Likely work';
  return arr;}
const placeLabel=c=>c.name||`${c.lat.toFixed(3)}, ${c.lng.toFixed(3)}`;
function patterns(ev){const hr=Array(24).fill(0),dw=Array(7).fill(0);let night=0;
  for(const e of ev){const d=new Date(e.t),h=d.getHours();hr[h]++;dw[d.getDay()]++;if(h<5)night++;}
  return{peak:hr.indexOf(Math.max(...hr)),day:DAYN[dw.indexOf(Math.max(...dw))],night:Math.round(night/ev.length*100)};}
function uniqContacts(list){const m=new Map();for(const c of list){const k=c.platform+'|'+c.kind+'|'+c.name.toLowerCase();if(!m.has(k))m.set(k,c);}return[...m.values()];}
function timedEvents(pf){return S.activities.filter(a=>a.t&&(!pf||pf==='all'||a.platform===pf)).concat(S.locations.filter(l=>l.t&&(!pf||pf==='all'||l.platform===pf)));}

function computeAll(){
  const F=[];
  const locs=S.locations,places=S.places;
  if(locs.length||places.length){const cl=clusters(locs);const home=cl.find(c=>c.tag==='Likely home');const det=[];
    if(locs.length)det.push(`${fmt(locs.length)} location records covering ${cl.length} distinct area${cl.length===1?'':'s'}${spanText(locs)}`);
    if(places.length)det.push(`${places.length} named place${places.length===1?'':'s'} of interest`);
    F.push({id:'location',cat:'location',title:'Location history',level:(locs.length>=20||cl.length>=3)?'High':'Medium',
      detected:det.join('; ')+'.',why:'Could reveal routines and frequently visited places.',
      impact:home?`The place recorded most often at night (${placeLabel(home)}) is very likely your home. Together with daytime records, someone could work out where you live, where you work and when you’re usually away.`:'Someone could work out where you spend time and when you’re usually away from home.',
      platforms:uniq(locs.concat(places).map(x=>x.platform)),count:locs.length+places.length});}
  const se=S.activities.filter(a=>a.type==='search');
  if(se.length){const groups=Object.keys(SENS).filter(g=>se.some(a=>SENS[g].test(a.text)));const sens=se.filter(a=>Object.values(SENS).some(r=>r.test(a.text)));
    F.push({id:'search',cat:'search',title:'Search history',level:(se.length>=50||sens.length)?'High':se.length>=5?'Medium':'Low',
      detected:`${fmt(se.length)} searches${spanText(se)}${sens.length?`, including ${fmt(sens.length)} about sensitive topics`:''}.`,
      why:'May reveal personal interests or sensitive concerns.',
      impact:groups.length?`Your searches touch on ${groups.join(', ')}. These topics can be used to profile you for ads or pricing, and would be embarrassing or harmful if your account were accessed.`:'Search terms show what you’re curious or worried about and can be used to profile you.',
      platforms:uniq(se.map(a=>a.platform)),count:se.length});}
  const ev=timedEvents();
  if(ev.length>=10){const P=patterns(ev);
    F.push({id:'activity',cat:'activity',title:'Activity patterns',level:ev.length>=50?'Medium':'Low',
      detected:`${fmt(ev.length)} timestamped events. Most active around ${hourLabel(P.peak)}, busiest on ${P.day}s, ${P.night}% of activity between midnight and 5 AM.`,
      why:'Could expose daily habits and active hours.',
      impact:'Timestamps show when you sleep, commute and are online, which makes it easier to predict when you’re away from home or reachable.',
      platforms:uniq(ev.map(e=>e.platform)),count:ev.length});}
  const uc=uniqContacts(S.contacts);
  if(uc.length){const kinds={};uc.forEach(c=>kinds[c.kind]=(kinds[c.kind]||0)+1);
    F.push({id:'contacts',cat:'contacts',title:'Connections',level:uc.length>=10?'Medium':'Low',
      detected:`${fmt(uc.length)} connections: ${Object.entries(kinds).map(([k,n])=>`${fmt(n)} ${k}`).join(', ')}.`,
      why:'May reveal social relationships.',
      impact:'Your network shows friends, family and colleagues. It can be used to target the people close to you with scams or to impersonate you convincingly.',
      platforms:uniq(uc.map(c=>c.platform)),count:uc.length});}
  const labels=uniq(S.interests.map(i=>i.label.toLowerCase()));const listens=S.activities.filter(a=>a.type==='listen');const artists=uniq(listens.map(a=>a.who).filter(Boolean));
  if(labels.length||listens.length){const inf=S.interests.filter(i=>/inferen|ad /i.test(i.source)).length;
    const parts=[];if(labels.length)parts.push(`${labels.length} interest or ad-targeting labels`);if(listens.length)parts.push(`${fmt(listens.length)} plays across ${artists.length} artists`);
    F.push({id:'interests',cat:'interests',title:'Interests & ad profile',level:(inf>=10||labels.length>=15)?'Medium':'Low',
      detected:parts.join(' and ')+'.',why:'May be used to profile your preferences.',
      impact:'Platforms and advertisers use these labels to decide what you see. Some, such as finance, health or life events, are sensitive in their own right.',
      platforms:uniq(S.interests.map(i=>i.platform).concat(listens.map(a=>a.platform))),count:labels.length+listens.length});}
  if(S.identifiers.length){const types=uniq(S.identifiers.map(i=>i.type));const strong=types.some(t=>/Phone|Birth|IP|Postal/.test(t));
    F.push({id:'identifiers',cat:'identifiers',title:'Personal identifiers',level:strong?'High':'Medium',
      detected:`Found ${types.map(t=>t==='IP address'?t:t.toLowerCase()).join(', ')}${S.identifiers.filter(i=>i.type==='IP address').length>1?` (${S.identifiers.filter(i=>i.type==='IP address').length} IP addresses)`:''}.`,
      why:'Directly identifies you and links your accounts together.',
      impact:'Phone number, birth date and IP addresses are the details used in account recovery, SIM-swap attacks and identity fraud.',
      platforms:uniq(S.identifiers.map(i=>i.platform)),count:S.identifiers.length});}
  F.sort((a,b)=>LV[b.level]-LV[a.level]);
  S.findings=F;
  const w={High:15,Medium:8,Low:3};
  S.score=F.length?Math.max(8,100-F.reduce((s,f)=>s+w[f.level],0)):null;
  S.actions=computeActions(F);
}
const scoreLabel=s=>s>=75?'Well protected':s>=50?'Moderate exposure':'High exposure';
