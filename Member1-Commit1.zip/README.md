# PrivacyLens · Team GodZilla

PrivacyLens is a local-first personal privacy auditor. Upload the data exports you download from **Google**, **Instagram** or **Spotify**, and it turns them into a visual picture of your digital footprint, a risk analysis and a prioritized action plan telling you what to delete, restrict or lock down first.

Archives are analyzed in the browser and never uploaded. Signed-in users only save a summary of their results.

**Live site:** https://roaring-fenglisu-44da69.netlify.app/

## Features
- **Dashboard:** privacy score, category risk radar, records by platform, top concerns
- **Upload & analyze:** drag-and-drop ZIP upload, automatic platform detection, demo data
- **Digital footprint:** location plot and most-visited places, interests, connections, activity timeline and heatmap
- **Risk analyzer:** what each kind of data could reveal, rated high, medium or low
- **Action plan:** prioritized steps with links to the right privacy settings
- **Privacy report:** PDF and JSON download
- **Accounts:** sign up, sign in or continue as guest; the first account becomes admin
- **Admin:** all users and their results, manage admins, post a notice to everyone

## Project structure
```
public/
  index.html                 Page layout and navigation
  css/                       Styles, one file per area (base, dashboard, upload, ...)
  js/analyzer/               Reads Google, Instagram and Spotify exports; risk engine; action library
  js/charts/                 Score ring, radar, platform bars, location plot, timeline, heatmap
  js/pages/                  One file per page
  js/account/                Sign-in, sessions, saved results, admin page
  js/report/export.js        PDF and JSON downloads
  js/main.js                 Start-up and event handling
  sample-data/               Sample Google, Instagram and Spotify exports for testing
netlify/functions/
  api.mjs                    Accounts and admin API
  lib/                       Responses, password hashing and tokens, storage helpers
netlify.toml                 Netlify settings
```

## Run locally
```
npm install
npm run dev
```
The site opens at http://localhost:8888.

## Deploy
Connect this repository to Netlify (**Add new site → Import an existing project → GitHub**). Settings come from `netlify.toml`.

## Team GodZilla
| Member | Area |
| --- | --- |
| Member 1 | Project setup, page layout and design |
| Member 2 | Data parsing: Google, Instagram, Spotify, sample data |
| Member 3 | Risk engine, charts and pages |
| Member 4 | Accounts, admin, backend API and reports |
