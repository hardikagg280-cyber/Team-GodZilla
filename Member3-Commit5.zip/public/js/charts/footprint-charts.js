/* Footprint charts: location plot, activity timeline, day/hour heatmap */
function filt(arr){return UI.explPf==='all'?arr:arr.filter(x=>x.platform===UI.explPf);}
function locPlot(cl,locs){const W=680,H=380,P=40;if(!cl.length)return'';
  const home=cl[0];const near=x=>Math.abs(x.lat-home.lat)<0.6&&Math.abs(x.lng-home.lng)<0.6;
  const top=cl.filter(near).slice(0,80);const away=cl.filter(x=>!near(x));
  let a=Infinity,b=-Infinity,c=Infinity,d=-Infinity;for(const x of top){a=Math.min(a,x.lat);b=Math.max(b,x.lat);c=Math.min(c,x.lng);d=Math.max(d,x.lng);}
  const k=Math.cos((a+b)/2*Math.PI/180);let rx=Math.max((d-c)*k,0.02),ry=Math.max(b-a,0.02);const sc=Math.min((W-2*P-150)/rx,(H-2*P)/ry);
  const cx=(c+d)/2,cy=(a+b)/2;const X=g=>W/2+(g-cx)*k*sc,Y=l=>H/2-(l-cy)*sc;
  const pts=[];const inView=locs.filter(l=>Math.abs(l.lat-home.lat)<0.6&&Math.abs(l.lng-home.lng)<0.6);const step=Math.max(1,Math.floor(inView.length/1500));
  for(let i=0;i<inView.length;i+=step){const l=inView[i];pts.push(`<circle cx="${X(l.lng).toFixed(1)}" cy="${Y(l.lat).toFixed(1)}" r="1.7" fill="var(--accent)" fill-opacity=".3"/>`);}
  const maxN=top[0].n,rad=x=>Math.max(5,Math.sqrt(x.n/maxN)*24);
  const circ=top.map(x=>{const t=x.tag;return `<circle cx="${X(x.lng).toFixed(1)}" cy="${Y(x.lat).toFixed(1)}" r="${rad(x).toFixed(1)}" fill="${t?'var(--high)':'var(--accent)'}" fill-opacity=".14" stroke="${t?'var(--high)':'var(--accent)'}" stroke-width="1.5"><title>${esc(placeLabel(x))}: ${x.n} records</title></circle>`;}).join('');
  const boxes=[];const labels=top.slice(0,8).map(x=>{const r=rad(x),t=(x.tag?x.tag+': ':'')+placeLabel(x),tt=t.length>38?t.slice(0,37)+'…':t,w=tt.length*6.6;
      let lx=X(x.lng)+r+6,anchor='start';if(lx+w>W-8){lx=X(x.lng)-r-6;anchor='end';}const x0=anchor==='start'?lx:lx-w;let ly=Y(x.lat)+4;
      for(let tries=0;tries<6;tries++){if(!boxes.some(bx=>x0<bx[0]+bx[2]&&x0+w>bx[0]&&Math.abs(ly-bx[1])<15))break;ly+=15;}
      if(boxes.some(bx=>x0<bx[0]+bx[2]&&x0+w>bx[0]&&Math.abs(ly-bx[1])<15))return'';boxes.push([x0,ly,w]);
      return `<text x="${lx.toFixed(1)}" y="${ly.toFixed(1)}" text-anchor="${anchor}" font-size="12.5" font-weight="600" fill="var(--ink)" paint-order="stroke" stroke="var(--surface-2)" stroke-width="4" stroke-linejoin="round">${esc(tt)}</text>`;}).join('');
  const grid=[1,2,3].map(i=>`<line x1="${W*i/4}" y1="0" x2="${W*i/4}" y2="${H}" stroke="var(--line)" stroke-dasharray="3 5"/><line x1="0" y1="${H*i/4}" x2="${W}" y2="${H*i/4}" stroke="var(--line)" stroke-dasharray="3 5"/>`).join('');
  const kmW=Math.round(W/sc/k*111);
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;min-width:520px" role="img" aria-label="Plot of recorded locations around your most-recorded place"><rect width="${W}" height="${H}" rx="14" fill="var(--surface-2)"/>${grid}${pts.join('')}${circ}${labels}
    <text x="14" y="${H-14}" font-size="11" fill="var(--muted)">North is up · view about ${kmW} km wide · circle size = number of records</text></svg>
    ${away.length?`<p class="muted small" style="margin:10px 4px 0">Also recorded outside this view: ${away.slice(0,5).map(x=>esc(placeLabel(x))+' ('+fmt(x.n)+')').join(', ')}${away.length>5?` and ${away.length-5} more`:''}.</p>`:''}`;}
function monthBars(ev){const m=new Map();for(const e of ev){const d=new Date(e.t);const k=d.getFullYear()*12+d.getMonth();m.set(k,(m.get(k)||0)+1);}
  if(!m.size)return'';const ks=[...m.keys()];let lo=Math.min(...ks);const hi=Math.max(...ks);if(hi-lo>59)lo=hi-59;
  const n=hi-lo+1,W=680,H=210,L=44,B=28,T=12;const max=Math.max(...[...m.entries()].filter(([k])=>k>=lo).map(e=>e[1]));const bw=(W-L-8)/n;
  const nice=Math.ceil(max/4/Math.pow(10,Math.floor(Math.log10(Math.max(1,max/4)))))*Math.pow(10,Math.floor(Math.log10(Math.max(1,max/4))));const top=nice*4;
  let s=`<svg viewBox="0 0 ${W} ${H}" style="width:100%;min-width:520px" role="img" aria-label="Activity per month">`;
  for(let i=0;i<=4;i++){const y=T+(H-T-B)*(1-i/4);s+=`<line x1="${L}" x2="${W}" y1="${y}" y2="${y}" stroke="var(--line)"/><text x="${L-8}" y="${y+4}" text-anchor="end" font-size="11" fill="var(--muted)">${fmt(nice*i)}</text>`;}
  const every=Math.ceil(n/9);
  for(let i=0;i<n;i++){const k=lo+i,v=m.get(k)||0,h=(H-T-B)*v/top,x=L+i*bw+bw*0.15;
    s+=`<rect x="${x.toFixed(1)}" y="${(H-B-h).toFixed(1)}" width="${(bw*0.7).toFixed(1)}" height="${h.toFixed(1)}" rx="3" fill="var(--accent)"><title>${new Date(Math.floor(k/12),k%12).toLocaleDateString(undefined,{month:'short',year:'numeric'})}: ${fmt(v)}</title></rect>`;
    if(i%every===0)s+=`<text x="${(x+bw*0.35).toFixed(1)}" y="${H-8}" text-anchor="middle" font-size="11" fill="var(--muted)">${new Date(Math.floor(k/12),k%12).toLocaleDateString(undefined,{month:'short',year:'2-digit'})}</text>`;}
  return s+'</svg>';}
function heat(ev){const g=Array.from({length:7},()=>Array(24).fill(0));for(const e of ev){const d=new Date(e.t);g[d.getDay()][d.getHours()]++;}
  const max=Math.max(1,...g.flat());const c=24,L=40,T=22,W=L+24*c+4,H=T+7*c+4;const dn=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  let s=`<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-width:${W*1.25}px;min-width:520px" role="img" aria-label="Activity by day of week and hour">`;
  [0,6,12,18].forEach(h=>s+=`<text x="${L+h*c+2}" y="14" font-size="11" fill="var(--muted)">${hourLabel(h)}</text>`);
  for(let d=0;d<7;d++){s+=`<text x="${L-8}" y="${T+d*c+16}" text-anchor="end" font-size="11" fill="var(--muted)">${dn[d]}</text>`;
    for(let h=0;h<24;h++){const v=g[d][h];s+=`<rect x="${L+h*c+1}" y="${T+d*c+1}" width="${c-2}" height="${c-2}" rx="4" fill="${v?'var(--accent)':'var(--surface-2)'}" fill-opacity="${v?(0.12+0.88*v/max).toFixed(2):1}"><title>${dn[d]} ${hourLabel(h)}: ${v}</title></rect>`;}}
  return s+'</svg>';}
